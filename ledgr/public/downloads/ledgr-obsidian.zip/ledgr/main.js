"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/main.ts
var main_exports = {};
__export(main_exports, {
  DEFAULT_SETTINGS: () => DEFAULT_SETTINGS,
  SECRET_ID: () => SECRET_ID,
  VIDEO_FILE: () => VIDEO_FILE,
  VIDEO_URL: () => VIDEO_URL,
  default: () => LedgrPlugin
});
module.exports = __toCommonJS(main_exports);
var import_obsidian4 = require("obsidian");

// src/api.ts
var API_BASE = "https://www.ledgrjournal.app/api/v1";
var UPGRADE_URL = "https://www.ledgrjournal.app/plus?plan=pro";
var KEYS_URL = "https://www.ledgrjournal.app/settings/api";
var LedgrApiError = class extends Error {
  constructor(kind, message2, status = 0, retryAfterMs = 0) {
    super(message2);
    this.kind = kind;
    this.status = status;
    this.retryAfterMs = retryAfterMs;
    this.name = "LedgrApiError";
  }
};
function errorFrom(res) {
  const body = res.json;
  const code = body?.error?.code ?? "";
  const msg = body?.error?.message ?? `LEDGR answered ${res.status}.`;
  if (res.status === 401) return new LedgrApiError("invalid_key", msg, 401);
  if (res.status === 402) return new LedgrApiError("not_pro", msg, 402);
  if (res.status === 404 && code === "no_journal") return new LedgrApiError("no_journal", msg, 404);
  if (res.status === 429) {
    const header = Object.entries(res.headers ?? {}).find(([k]) => k.toLowerCase() === "retry-after")?.[1];
    const secs = Number(header);
    return new LedgrApiError("rate_limited", msg, 429, (Number.isFinite(secs) && secs > 0 ? secs : 30) * 1e3);
  }
  return new LedgrApiError("server", msg, res.status);
}
var RateLimiter = class {
  constructor(max = 100, windowMs = 6e4, now = Date.now, sleep = (ms) => new Promise((r) => setTimeout(r, ms))) {
    this.max = max;
    this.windowMs = windowMs;
    this.now = now;
    this.sleep = sleep;
    this.stamps = [];
    this.pausedUntil = 0;
  }
  /** How long the next request would have to wait (0 = now). */
  waitMs() {
    const t = this.now();
    this.stamps = this.stamps.filter((s) => t - s < this.windowMs);
    const pause = Math.max(0, this.pausedUntil - t);
    const full = this.stamps.length >= this.max ? this.windowMs - (t - this.stamps[0]) : 0;
    return Math.max(pause, full);
  }
  async acquire() {
    for (let w = this.waitMs(); w > 0; w = this.waitMs()) await this.sleep(w);
    this.stamps.push(this.now());
  }
  pause(ms) {
    this.pausedUntil = Math.max(this.pausedUntil, this.now() + ms);
  }
};
var LedgrClient = class {
  constructor(o) {
    this.o = o;
    this.cache = /* @__PURE__ */ new Map();
    this.inflight = /* @__PURE__ */ new Map();
    this.now = o.now ?? Date.now;
    this.limiter = o.limiter ?? new RateLimiter(100, 6e4, this.now);
  }
  /** Forget cached answers (after a new key, or a manual refresh). */
  clear() {
    this.cache.clear();
  }
  /** GET a path such as "/stats?from=2026-11-01". Answers are cached for cacheMs (60 s by default). */
  async get(path, { fresh = false } = {}) {
    const key = this.o.getKey()?.trim();
    if (!key) throw new LedgrApiError("no_key", "Add your LEDGR API key in the plugin settings.");
    const hit = this.cache.get(path);
    if (!fresh && hit && this.now() - hit.at < (this.o.cacheMs ?? 6e4)) return hit.data;
    const running = this.inflight.get(path);
    if (running) return running;
    const p = (async () => {
      await this.limiter.acquire();
      let res;
      try {
        res = await this.o.transport({ url: (this.o.base ?? API_BASE) + path, method: "GET", headers: { Authorization: `Bearer ${key}`, Accept: "application/json" } });
      } catch {
        throw new LedgrApiError("offline", "Can't reach LEDGR. Check your internet connection.");
      }
      if (res.status < 200 || res.status >= 300) {
        const err = errorFrom(res);
        if (err.kind === "rate_limited") this.limiter.pause(err.retryAfterMs);
        throw err;
      }
      this.cache.set(path, { at: this.now(), data: res.json });
      return res.json;
    })();
    this.inflight.set(path, p);
    try {
      return await p;
    } finally {
      this.inflight.delete(path);
    }
  }
  me(opts) {
    return this.get("/me", opts);
  }
  /** Everything the command center needs: 4 requests. */
  async dashboard(today, opts) {
    const me = await this.me(opts);
    const from = isoDate(new Date(today.getTime() - 29 * 864e5));
    const [stats, stats30, acc] = await Promise.all([
      this.get("/stats", opts),
      this.get(`/stats?from=${from}`, opts),
      this.get("/accounts?status=active", opts)
    ]);
    return { me, stats, stats30, accounts: acc.accounts };
  }
};
function isoDate(d) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

// src/connect.ts
var post = (transport2, path, body) => transport2({ url: API_BASE + path, method: "POST", headers: { "Content-Type": "application/json", Accept: "application/json" }, body: JSON.stringify(body) });
var message = (json, fallback) => json?.error?.message ?? fallback;
async function startConnect(transport2, client) {
  let res;
  try {
    res = await post(transport2, "/device/code", { client });
  } catch {
    throw new Error("Can't reach LEDGR. Check your internet connection.");
  }
  if (res.status !== 200) throw new Error(message(res.json, `LEDGR answered ${res.status}.`));
  return res.json;
}
async function pollConnect(transport2, deviceCode) {
  let res;
  try {
    res = await post(transport2, "/device/token", { device_code: deviceCode });
  } catch {
    return { kind: "pending" };
  }
  if (res.status === 200) {
    const key = res.json?.key;
    return key ? { kind: "ok", key } : { kind: "failed", message: "LEDGR didn't send a key. Try again." };
  }
  if (res.status === 428 || res.status === 429 || res.status >= 500) return { kind: "pending" };
  return { kind: "failed", message: message(res.json, `LEDGR answered ${res.status}.`) };
}
async function waitForKey(o) {
  const until = o.now() + o.code.expires_in * 1e3, every = Math.max(2, o.code.interval) * 1e3;
  while (o.now() < until) {
    await o.sleep(every);
    if (o.cancelled()) return null;
    const r = await o.poll(o.code.device_code);
    if (r.kind === "ok") return r.key;
    if (r.kind === "failed") throw new Error(r.message);
  }
  throw new Error("The code expired. Start again.");
}

// src/cc/instruments.ts
var SPEC = {
  MGC: ["MICRO GOLD", 10, 0.1, "COMEX:MGC1!", "OANDA:XAUUSD", "GOLD", ["USD"]],
  GC: ["GOLD", 100, 0.1, "COMEX:GC1!", "OANDA:XAUUSD", "GOLD", ["USD"]],
  SIL: ["MICRO SILVER", 1e3, 5e-3, "COMEX:SIL1!", "OANDA:XAGUSD", "SILVER", ["USD"]],
  SI: ["SILVER", 5e3, 5e-3, "COMEX:SI1!", "OANDA:XAGUSD", "SILVER", ["USD"]],
  MCL: ["MICRO CRUDE", 100, 0.01, "NYMEX:MCL1!", "TVC:USOIL", "CRUDE", ["USD"]],
  CL: ["CRUDE OIL", 1e3, 0.01, "NYMEX:CL1!", "TVC:USOIL", "CRUDE", ["USD"]],
  MNQ: ["MICRO NASDAQ", 2, 0.25, "CME_MINI:MNQ1!", "FOREXCOM:NSXUSD", "NASDAQ", ["USD"]],
  NQ: ["E-MINI NASDAQ", 20, 0.25, "CME_MINI:NQ1!", "FOREXCOM:NSXUSD", "NASDAQ", ["USD"]],
  MES: ["MICRO S&P", 5, 0.25, "CME_MINI:MES1!", "FOREXCOM:SPXUSD", "S&P 500", ["USD"]],
  ES: ["E-MINI S&P", 50, 0.25, "CME_MINI:ES1!", "FOREXCOM:SPXUSD", "S&P 500", ["USD"]],
  MYM: ["MICRO DOW", 0.5, 1, "CBOT_MINI:MYM1!", "FOREXCOM:DJI", "DOW", ["USD"]],
  YM: ["E-MINI DOW", 5, 1, "CBOT_MINI:YM1!", "FOREXCOM:DJI", "DOW", ["USD"]],
  M2K: ["MICRO RUSSELL", 5, 0.1, "CME_MINI:M2K1!", "CME_MINI:M2K1!", "RUSSELL", ["USD"]],
  RTY: ["E-MINI RUSSELL", 50, 0.1, "CME_MINI:RTY1!", "CME_MINI:RTY1!", "RUSSELL", ["USD"]],
  M6E: ["MICRO EUR/USD", 12500, 1e-4, "CME:M6E1!", "FX:EURUSD", "EURUSD", ["USD", "EUR"]],
  "6E": ["EURO FX", 125e3, 5e-5, "CME:6E1!", "FX:EURUSD", "EURUSD", ["USD", "EUR"]],
  "6B": ["BRITISH POUND", 62500, 1e-4, "CME:6B1!", "FX:GBPUSD", "GBPUSD", ["USD", "GBP"]],
  "6J": ["JAPANESE YEN", 125e5, 5e-7, "CME:6J1!", "FX:USDJPY", "USDJPY", ["USD", "JPY"]],
  MBT: ["MICRO BITCOIN", 0.1, 5, "CME:MBT1!", "BITSTAMP:BTCUSD", "BITCOIN", ["USD"]],
  BTC: ["BITCOIN FUTURES", 5, 5, "CME:BTC1!", "BITSTAMP:BTCUSD", "BITCOIN", ["USD"]],
  MET: ["MICRO ETHER", 0.1, 0.5, "CME:MET1!", "BITSTAMP:ETHUSD", "ETHER", ["USD"]],
  ZN: ["10Y NOTE", 1e3, 0.015625, "CBOT:ZN1!", "CBOT:ZN1!", "10Y NOTE", ["USD"]],
  NG: ["NATURAL GAS", 1e4, 1e-3, "NYMEX:NG1!", "NYMEX:NG1!", "NAT GAS", ["USD"]],
  HG: ["COPPER", 25e3, 5e-4, "COMEX:HG1!", "COMEX:HG1!", "COPPER", ["USD"]]
};
var ROOTS = Object.keys(SPEC).sort((a, b) => b.length - a.length);
var FXC = ["USD", "EUR", "GBP", "JPY", "AUD", "NZD", "CAD", "CHF", "CNH", "SGD", "HKD", "ZAR", "MXN", "SEK", "NOK", "TRY"];
function rootOf(sym) {
  const s = String(sym || "").toUpperCase().replace(/^[A-Z_]+:/, "").replace(/[\s/\-.]/g, "");
  for (const r of ROOTS) if (s.startsWith(r) && /^([FGHJKMNQUVXZ]\d{1,2})?(\d!)?$/.test(s.slice(r.length))) return r;
  return s || "\u2014";
}
function prof(root, pvHint = 0) {
  const s = SPEC[root];
  if (s) return { code: root, name: s[0], pv: pvHint || s[1], tick: s[2], tv: s[3], px: s[4], short: s[5], ccy: s[6], fut: true };
  const r = root, a = r.slice(0, 3), b = r.slice(3);
  if (r.length === 6 && (a === "XAU" || a === "XAG")) return { code: r, name: a === "XAU" ? "SPOT GOLD" : "SPOT SILVER", pv: pvHint || 100, tick: 0.01, tv: "OANDA:" + r, px: "OANDA:" + r, short: a === "XAU" ? "GOLD" : "SILVER", ccy: [b], fut: false };
  if (r.length === 6 && FXC.includes(a) && FXC.includes(b)) return { code: r, name: a + "/" + b, pv: pvHint || (b === "JPY" ? 1e3 : 1e5), tick: b === "JPY" ? 1e-3 : 1e-5, tv: "FX:" + r, px: "FX:" + r, short: r, ccy: [a, b], fut: false };
  if (/^(BTC|ETH|SOL|XRP)(USD|USDT)$/.test(r)) return { code: r, name: r.slice(0, 3) + " SPOT", pv: pvHint || 1, tick: 0.01, tv: "BITSTAMP:" + r.replace("USDT", "USD"), px: "BITSTAMP:" + r.replace("USDT", "USD"), short: r.slice(0, 3), ccy: ["USD"], fut: false };
  return { code: r, name: r, pv: pvHint || 1, tick: 0.01, tv: r, px: r, short: r, ccy: ["USD"], fut: false };
}
var dec = (x) => {
  const s = String(x);
  return s.includes("e-") ? +s.split("e-")[1] : (s.split(".")[1] || "").length;
};
var TZXY = {
  "Asia/Dubai": [25.2, 55.3],
  "Asia/Riyadh": [24.7, 46.7],
  "Asia/Qatar": [25.3, 51.5],
  "Europe/London": null,
  "Europe/Paris": [48.9, 2.35],
  "Europe/Berlin": [52.5, 13.4],
  "Europe/Madrid": [40.4, -3.7],
  "Europe/Rome": [41.9, 12.5],
  "Europe/Amsterdam": [52.4, 4.9],
  "Europe/Zurich": [47.4, 8.5],
  "Europe/Istanbul": [41, 29],
  "Europe/Moscow": [55.8, 37.6],
  "Africa/Lagos": [6.5, 3.4],
  "Africa/Johannesburg": [-26.2, 28],
  "Africa/Cairo": [30, 31.2],
  "Asia/Kolkata": [19, 72.8],
  "Asia/Karachi": [24.9, 67],
  "Asia/Singapore": [1.35, 103.8],
  "Asia/Hong_Kong": [22.3, 114.2],
  "Asia/Shanghai": [31.2, 121.5],
  "Asia/Tokyo": null,
  "Asia/Seoul": [37.6, 127],
  "Asia/Manila": [14.6, 121],
  "Asia/Jakarta": [-6.2, 106.8],
  "Australia/Sydney": [-33.9, 151.2],
  "Australia/Melbourne": [-37.8, 145],
  "Pacific/Auckland": [-36.8, 174.8],
  "America/New_York": null,
  "America/Chicago": null,
  "America/Toronto": [43.7, -79.4],
  "America/Los_Angeles": [34, -118.2],
  "America/Denver": [39.7, -105],
  "America/Phoenix": [33.4, -112],
  "America/Mexico_City": [19.4, -99.1],
  "America/Sao_Paulo": [-23.5, -46.6],
  "America/Bogota": [4.7, -74.1],
  "America/Argentina/Buenos_Aires": [-34.6, -58.4]
};
var cityOf = (z) => z === "UTC" || z === "Etc/UTC" ? "UTC" : z.split("/").pop().replace(/_/g, " ").toUpperCase();
var okTZ = (z) => {
  try {
    new Intl.DateTimeFormat("en-US", { timeZone: z });
    return !!z;
  } catch {
    return false;
  }
};

// src/cc/logic.ts
function zone(tz) {
  const f = new Intl.DateTimeFormat("en-US", { timeZone: tz, hourCycle: "h23", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit" });
  const tzOff = (d) => {
    const o = {};
    f.formatToParts(d).forEach((x) => o[x.type] = x.value);
    return Date.UTC(+o.year, +o.month - 1, +o.day, +o.hour % 24, +o.minute, +o.second) - Math.floor(d.getTime() / 1e3) * 1e3;
  };
  const local = (d) => new Date(d.getTime() + tzOff(d));
  const dayKey = (d) => local(d).toISOString().slice(0, 10);
  return { tz, tzOff, local, dayKey };
}
var fmtT = (tz, d = /* @__PURE__ */ new Date()) => d.toLocaleTimeString("en-GB", { timeZone: tz, hour12: false });
var money = (v) => !isFinite(v) ? "\u2014" : (v < 0 ? "-$" : "$") + Math.abs(v).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
var smoney = (v) => !isFinite(v) ? "\u2014" : (v > 0 ? "+" : "") + money(v);
var cls = (v) => v > 0 ? "up" : v < 0 ? "down" : "";
var esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
var fmtDur = (m) => {
  m = Math.max(0, Math.round(m));
  const d = Math.floor(m / 1440), h = Math.floor(m % 1440 / 60), mm = m % 60;
  return (d ? d + "d " : "") + (h ? h + "h " : "") + mm + "m";
};
function cd(ms) {
  const t = Math.max(0, Math.floor(ms / 1e3)), h = Math.floor(t / 3600), m = Math.floor(t % 3600 / 60), x = t % 60;
  return (h ? h + ":" : "") + String(m).padStart(2, "0") + ":" + String(x).padStart(2, "0");
}
var n = (v) => typeof v === "number" && isFinite(v) ? v : NaN;
function norm(t) {
  const sym = String(t.symbol || "").toUpperCase(), dir = t.direction === "short" ? "short" : "long";
  const qty = n(t.quantity), en = n(t.entryPrice), ex = n(t.exitPrice), pts = isFinite(en) && isFinite(ex) ? (ex - en) * (dir === "short" ? -1 : 1) : NaN;
  const exits = (t.executions ?? []).filter((e) => e.kind === "exit").map((e) => Date.parse(e.time)).filter(isFinite);
  const opened = t.openedAt ? Date.parse(t.openedAt) : NaN;
  const dayOnly = t.date ? Date.parse(t.date + "T12:00:00Z") : NaN;
  const close = exits.length ? Math.max(...exits) : isFinite(opened) ? opened : dayOnly;
  return {
    id: t.id,
    sym,
    root: rootOf(sym),
    pvj: n(t.pointValue),
    acct: String(t.accountId ?? ""),
    dir,
    qty,
    en,
    ex,
    net: n(t.net),
    pts,
    r: n(t.r),
    time: isFinite(close) ? new Date(close) : null,
    tin: isFinite(opened) ? new Date(opened) : isFinite(close) ? new Date(close) : null,
    status: String(t.status || "closed").toLowerCase(),
    setup: String(t.setup || t.strategy || "\u2014")
  };
}
var closedOf = (tr) => tr.filter((t) => t.status === "closed" && isFinite(t.net) && t.time && !isNaN(+t.time)).sort((a, b) => +a.time - +b.time);
function S(ts) {
  const w = ts.filter((t) => t.net > 0), l = ts.filter((t) => t.net < 0), gw = w.reduce((s, t) => s + t.net, 0), gl = -l.reduce((s, t) => s + t.net, 0);
  let eq = 0, pk = 0, dd = 0;
  ts.forEach((t) => {
    eq += t.net;
    pk = Math.max(pk, eq);
    dd = Math.max(dd, pk - eq);
  });
  const rs = ts.map((t) => t.r).filter(isFinite);
  return { n: ts.length, net: gw - gl, win: w.length + l.length ? w.length / (w.length + l.length) : NaN, pf: gl ? gw / gl : gw ? Infinity : NaN, dd, avgR: rs.length ? rs.reduce((a, b) => a + b, 0) / rs.length : NaN, gw, gl, w: w.length, l: l.length };
}
var sessOf = (d) => {
  const h = d.getUTCHours() + d.getUTCMinutes() / 60;
  return h >= 13.5 && h < 21 ? "NEW YORK" : h >= 7 && h < 13.5 ? "LONDON" : "ASIA";
};
function behaviour(c) {
  let tilt = 0;
  for (let i = 1; i < c.length; i++) if (c[i - 1].net < 0 && +c[i].time - +c[i - 1].time < 20 * 6e4) tilt++;
  return { tilt, bigL: c.filter((t) => isFinite(t.r) && t.r < -1.2).length };
}
function groupBy(c, f) {
  const g = {};
  c.forEach((t) => {
    const k = f(t);
    (g[k] = g[k] || []).push(t);
  });
  return Object.entries(g).map(([k, a]) => ({ k, ...S(a) })).sort((a, b) => b.net - a.net);
}
function brainLabels(c) {
  const s = S(c), best = groupBy(c, (t) => t.setup)[0], { tilt, bigL } = behaviour(c);
  const none = "awaiting data";
  return {
    PSYCHE: c.length ? `${tilt} quick re-entries after losses` : none,
    STRATEGY: best ? `best setup: ${best.k}` : none,
    RULES: c.length ? `${bigL} losses beyond -1.2R` : none,
    PERFORMANCE: c.length ? `${smoney(s.net)} \xB7 win ${(s.win * 100).toFixed(0)}%` : none,
    RISK: c.length ? `max drawdown ${money(s.dd)}` : none,
    LEARNING: "see Psyche report",
    BODY: "sleep \xB7 focus \xB7 energy"
  };
}
function instrumentsOf(all) {
  const cnt = {};
  all.forEach((t) => {
    const k = t.root || "\u2014";
    cnt[k] = (cnt[k] || 0) + 1;
  });
  return { list: Object.keys(cnt).filter((k) => k !== "\u2014").sort((a, b) => cnt[b] - cnt[a]), cnt };
}
function focusOf(all, list, choice, fallback = "MGC") {
  const focus = choice === "AUTO" || choice === "ALL" ? list[0] : choice;
  const pvj = all.find((t) => t.root === focus && isFinite(t.pvj))?.pvj;
  return { focus, trades: choice === "ALL" || !focus ? all.slice() : all.filter((t) => t.root === focus), cur: prof(focus || fallback, pvj && isFinite(pvj) ? pvj : 0) };
}
var GUARD_DEFAULT = { loss: 200, trades: 4, consec: 2, cool: 20 };
function guardState(today, rg, now) {
  const net = today.reduce((a, t) => a + t.net, 0), count = today.length;
  let consec = 0;
  for (let i = today.length - 1; i >= 0 && today[i].net < 0; i--) consec++;
  const lastLoss = [...today].reverse().find((t) => t.net < 0);
  const coolLeft = lastLoss ? Math.max(0, +lastLoss.time + rg.cool * 6e4 - now) : 0;
  const why = [];
  let lvl = "OK";
  if (-net >= rg.loss) {
    lvl = "STOP";
    why.push("daily loss limit hit");
  }
  if (count >= rg.trades) {
    lvl = "STOP";
    why.push("max trades reached");
  }
  if (consec >= rg.consec) {
    lvl = "STOP";
    why.push(consec + " losses in a row");
  }
  if (lvl !== "STOP") {
    if (-net >= rg.loss * 0.7) {
      lvl = "CAUTION";
      why.push("near loss limit");
    }
    if (count >= rg.trades - 1) {
      lvl = "CAUTION";
      why.push("one trade left");
    }
    if (coolLeft > 0) {
      lvl = "CAUTION";
      why.push("cool-down " + cd(coolLeft));
    }
    if (consec === rg.consec - 1 && consec > 0) {
      lvl = "CAUTION";
      why.push("one more loss = stop");
    }
  }
  return { net, n: count, consec, coolLeft, lvl, why };
}
var SIZING_DEFAULT = { acc: 5e3, pct: 1, fee: 1.24, max: 10, en: "", st: "" };
function sizeFor(cur, s, en, st) {
  if (!isFinite(en) || !isFinite(st) || en === st) return null;
  const dist = Math.abs(en - st), risk = +s.acc * +s.pct / 100, per = dist * cur.pv + (+s.fee || 0);
  const raw = Math.floor(risk / per), max = +s.max || 99, contracts = Math.max(0, Math.min(max, raw)), sgn = en > st ? 1 : -1;
  return {
    contracts,
    raw,
    capped: raw > max,
    dir: en > st ? "LONG" : "SHORT",
    dist,
    ticks: Math.round(dist / cur.tick),
    perContract: per,
    planned: risk,
    actual: contracts * per,
    target: (r) => en + sgn * dist * r,
    reward: (r) => contracts * dist * cur.pv * r
  };
}
var IMP = { High: 3, Medium: 2, Low: 1, Holiday: 0 };
function newsClear(ev, ccy, now) {
  if (!ev) return null;
  return !ev.some((e) => e.i === 3 && ccy.includes(e.country) && +e.t - now > -5 * 6e4 && +e.t - now < 30 * 6e4);
}
function crossed(prevMs, remMs) {
  if (prevMs === void 0) return [];
  return [15, 5, 1, 0].filter((m) => prevMs > m * 6e4 && remMs <= m * 6e4);
}

// src/cc/calendar.ts
function toEvents(a) {
  return (a.events ?? []).map((e) => ({ ...e, title: String(e.title ?? ""), country: String(e.country ?? "").toUpperCase(), t: new Date(e.date), i: IMP[e.impact] ?? 0 })).filter((e) => !isNaN(+e.t)).sort((a2, b) => +a2.t - +b.t);
}

// src/cc/sync.ts
var PAGE = 500;
var FULL_EVERY_MS = 24 * 36e5;
var EMPTY_CACHE = { trades: [], lastSync: 0, lastFull: 0, syncedDay: "" };
var EDIT_MARGIN_MS = 10 * 6e4;
async function fetchTrades(get, q = {}) {
  const out = [];
  let ids = null;
  const extra = (q.from ? `&from=${q.from}` : "") + (q.updatedSince ? `&updatedSince=${encodeURIComponent(q.updatedSince)}` : "");
  for (let offset = 0; offset < 100 * PAGE; offset += PAGE) {
    const page = await get(`/trades?limit=${PAGE}&offset=${offset}${extra}`);
    if (offset === 0 && Array.isArray(page.ids)) ids = page.ids;
    out.push(...page.trades);
    if (page.trades.length < PAGE || out.length >= page.total) break;
  }
  return { trades: out, ids };
}
function mergeChanged(cached, changed, ids) {
  const keep = new Set(ids), fresh = new Map(changed.map((t) => [t.id, t]));
  return [...cached.filter((t) => keep.has(t.id) && !fresh.has(t.id)), ...changed];
}
function needsFull(c, now, force) {
  return force || !c.lastFull || !c.syncedDay || now - c.lastFull > FULL_EVERY_MS;
}
async function syncTrades(get, cache, now, today, force = false) {
  if (needsFull(cache, now, force)) {
    const { trades } = await fetchTrades(get);
    return { trades, lastSync: now, lastFull: now, syncedDay: today };
  }
  const since = new Date(cache.lastSync - EDIT_MARGIN_MS).toISOString();
  const changed = await fetchTrades(get, { updatedSince: since });
  if (changed.ids) return { trades: mergeChanged(cache.trades, changed.trades, changed.ids), lastSync: now, lastFull: cache.lastFull, syncedDay: today };
  return { trades: changed.trades, lastSync: now, lastFull: now, syncedDay: today };
}

// src/settings.ts
var import_obsidian = require("obsidian");
var KEY_PATTERN = /^ledgr_sk_[A-Za-z0-9_-]{20,}$/;
var LedgrSettingTab = class extends import_obsidian.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
    this.draft = "";
    this.status = null;
  }
  display() {
    const { containerEl: el } = this;
    el.empty();
    const connected = !!this.plugin.getKey();
    const s = this.plugin.cfg();
    new import_obsidian.Setting(el).setName("Connect LEDGR").setHeading();
    el.createEl("p", {
      cls: "setting-item-description",
      text: "Needs LEDGR Pro. The plugin's key is kept in Obsidian's secret storage on this device: it isn't written into your vault, and it's only sent to ledgrjournal.app."
    });
    const me = this.plugin.data.me;
    const statusEl = el.createDiv({ cls: "ledgr-settings-status" });
    const line = this.status ?? (connected ? me ? { tone: "ok", text: `Connected \xB7 key "${me.key.name}" \xB7 ${me.plan.name}${me.plan.until ? ` until ${new Date(me.plan.until).toLocaleDateString()}` : ""}` } : { tone: "info", text: "Key saved. Press Test connection." } : { tone: "info", text: "Not connected." });
    statusEl.addClass(`is-${line.tone}`);
    statusEl.setText(line.text);
    new import_obsidian.Setting(el).setName("Connect with LEDGR").setDesc("Approve this device in your browser. No key to copy. You can disconnect it any time in LEDGR \u2192 Settings \u2192 API.").addButton((b) => b.setButtonText(connected ? "Connect again" : "Connect with LEDGR").setCta().onClick(async () => {
      if (await this.plugin.connectWithLedgr()) {
        this.status = null;
        this.display();
      }
    }));
    new import_obsidian.Setting(el).setName("Or paste an API key").setDesc(connected ? "A key is saved. Paste a new one to replace it." : "From LEDGR \u2192 Settings \u2192 API. Starts with ledgr_sk_.").addText((t) => {
      t.inputEl.type = "password";
      t.inputEl.autocomplete = "off";
      t.setPlaceholder(connected ? "ledgr_sk_\u2026 (saved)" : "ledgr_sk_\u2026").setValue(this.draft).onChange((v) => {
        this.draft = v.trim();
      });
    }).addButton((b) => b.setButtonText("Test connection").onClick(() => void this.test())).addButton((b) => b.setButtonText("Disconnect").setWarning().setDisabled(!connected).onClick(async () => {
      await this.plugin.disconnect();
      this.draft = "";
      this.status = { tone: "info", text: "Disconnected. The key and the downloaded trades were removed from this device." };
      this.display();
    }));
    new import_obsidian.Setting(el).setName("Get an API key").setDesc("Create and revoke keys in LEDGR.").addButton((b) => b.setButtonText("Open LEDGR \u2192 API").onClick(() => window.open(KEYS_URL))).addButton((b) => b.setButtonText("Upgrade to LEDGR Pro").onClick(() => window.open(UPGRADE_URL)));
    new import_obsidian.Setting(el).setName("Command Center").setHeading();
    const sysTz = Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC";
    let tzWarn;
    new import_obsidian.Setting(el).setName("Time zone").setDesc(`Clocks, the session radar, today's trades and the calendar. Leave empty to use this device's (${sysTz}).`).addText((t) => t.setPlaceholder(sysTz).setValue(s.timezone).onChange(async (v) => {
      v = v.trim();
      if (v && !okTZ(v)) {
        tzWarn.setText(`Unknown time zone "${v}". Use a name like Asia/Dubai or America/New_York.`);
        return;
      }
      tzWarn.setText("");
      await this.plugin.updateSettings({ timezone: v });
    }));
    tzWarn = el.createDiv({ cls: "setting-item-description mod-warning" });
    new import_obsidian.Setting(el).setName("Default instrument").setDesc("AUTO uses the instrument you trade most. The ACCOUNT panel's menu switches it any time.").addDropdown((d) => {
      d.addOption("AUTO", "AUTO (most traded)");
      Object.entries(SPEC).forEach(([k, v]) => d.addOption(k, `${k} \xB7 ${v[0]}`));
      d.setValue(s.symbol || "AUTO").onChange(async (v) => {
        await this.plugin.updateSettings({ symbol: v });
        this.plugin.store.set("cc_ins", v);
      });
    });
    new import_obsidian.Setting(el).setName("Open in its own window").setDesc("Desktop: the Command Center opens full-window with no Obsidian tabs or sidebars around it (use the green button for full screen). Off: it opens as a tab and the side panels fold away.").addToggle((t) => t.setValue(s.ownWindow).onChange((v) => void this.plugin.updateSettings({ ownWindow: v })));
    new import_obsidian.Setting(el).setName("Sound").setDesc("Interface sounds, news alerts and the risk-guard alarm (made in the app, no audio files).").addToggle((t) => t.setValue(s.sound).onChange((v) => void this.plugin.updateSettings({ sound: v })));
    new import_obsidian.Setting(el).setName("Intro").setDesc("Play the ENGAGE intro when the Command Center opens. The BOOT button plays it any time.").addToggle((t) => t.setValue(s.intro).onChange((v) => void this.plugin.updateSettings({ intro: v })));
    new import_obsidian.Setting(el).setName("Live TradingView widgets").setDesc("Ticker tape, quote, charts, news and sentiment from tradingview.com, in sandboxed frames. Off: no connection to TradingView.").addToggle((t) => t.setValue(s.tvWidgets).onChange((v) => void this.plugin.updateSettings({ tvWidgets: v })));
    new import_obsidian.Setting(el).setName("Trades as notes").setHeading();
    el.createEl("p", {
      cls: "setting-item-description",
      text: 'Each trade becomes a note, linked to its day, setup, mistakes and tags, so the graph shows your patterns. LEDGR rewrites the part above "<!-- your notes -->" on every sync; whatever you write below it is never changed.'
    });
    new import_obsidian.Setting(el).setName("Folder").setDesc("Where the notes go: Trades, Days, Setups, Mistakes and Tags folders inside it.").addText((t) => t.setPlaceholder("LEDGR").setValue(s.notesFolder).onChange((v) => void this.plugin.updateSettings({ notesFolder: v.trim() || "LEDGR" })));
    new import_obsidian.Setting(el).setName("Sync automatically").setDesc('While Obsidian is open. Off: use the button or the command "LEDGR: Sync trades to notes".').addDropdown((d) => d.addOptions({ "0": "Off", "15": "Every 15 minutes", "30": "Every 30 minutes", "60": "Every hour", "240": "Every 4 hours" }).setValue(String(s.notesAuto)).onChange((v) => void this.plugin.updateSettings({ notesAuto: Number(v) })));
    new import_obsidian.Setting(el).setName("Sync now").setDesc("Downloads new trades and updates the notes.").addButton((b) => b.setButtonText("Sync trades to notes").setCta().setDisabled(!connected).onClick(async () => {
      b.setDisabled(true).setButtonText("Syncing\u2026");
      await this.plugin.syncToNotes(true);
      b.setDisabled(false).setButtonText("Sync trades to notes");
    }));
    new import_obsidian.Setting(el).setName("Starter vault").setDesc("Home dashboard (updates on sync), PARA folders and a daily trading-note template. Existing files are never changed.").addButton((b) => b.setButtonText("Create starter vault").onClick(() => void this.plugin.starter()));
  }
  async test() {
    if (this.draft) {
      if (!KEY_PATTERN.test(this.draft)) {
        this.status = { tone: "bad", text: "That doesn't look like a LEDGR key. Keys start with ledgr_sk_." };
        return this.display();
      }
      this.plugin.setKey(this.draft);
      this.draft = "";
    }
    if (!this.plugin.getKey()) {
      this.status = { tone: "bad", text: "Paste your API key first." };
      return this.display();
    }
    this.status = { tone: "info", text: "Testing\u2026" };
    this.display();
    try {
      const me = await this.plugin.client.me({ fresh: true });
      this.plugin.data.me = me;
      this.status = { tone: "ok", text: `Connected \xB7 key "${me.key.name}" \xB7 ${me.plan.name}${me.journal ? ` \xB7 ${me.journal.trades} trades` : " \xB7 no journal synced yet"}` };
      void this.plugin.sync(false);
    } catch (e) {
      const err = e instanceof LedgrApiError ? e : null;
      this.status = { tone: "bad", text: err?.message ?? "Couldn't connect." };
    }
    this.display();
  }
};

// src/notes/sync.ts
var import_obsidian2 = require("obsidian");

// src/notes/build.ts
var MARKER = "<!-- your notes -->";
var MARKER_RE = /<!--\s*your notes\s*-->/;
var safeName = (s) => s.replace(/[\\/:*?"<>|#^[\]]/g, " ").replace(/\s+/g, " ").trim().slice(0, 80);
var dirWord = (d) => d === "short" ? "Short" : d === "long" ? "Long" : "";
var setupOf = (t) => (t.setup || t.strategy || "").trim();
function tradeBaseName(t) {
  return safeName([t.date, t.symbol.toUpperCase(), dirWord(t.direction), setupOf(t)].filter(Boolean).join(" ")) || safeName(`${t.date} trade ${t.number}`);
}
var paths = (root) => ({
  trades: `${root}/Trades`,
  days: `${root}/Days`,
  setups: `${root}/Setups`,
  mistakes: `${root}/Mistakes`,
  tags: `${root}/Tags`,
  day: (d) => `${root}/Days/${d}.md`,
  setup: (s) => `${root}/Setups/${safeName(s)}.md`,
  mistake: (m) => `${root}/Mistakes/${safeName(m)}.md`,
  tag: (t) => `${root}/Tags/${safeName(t)}.md`
});
var link = (path, label) => `[[${path.replace(/\.md$/, "")}|${(label ?? path.split("/").pop().replace(/\.md$/, "")).replace(/[|\]]/g, " ")}]]`;
function assignPaths(trades, existing, taken, root) {
  const out = new Map(existing);
  const used = new Set(Array.from(taken, (p) => p.toLowerCase()));
  for (const t of [...trades].sort((a, b) => a.date.localeCompare(b.date) || a.number - b.number)) {
    if (out.has(t.id)) continue;
    const base = `${paths(root).trades}/${tradeBaseName(t)}`;
    let p = `${base}.md`;
    for (let i = 2; used.has(p.toLowerCase()); i++) p = `${base} (${i}).md`;
    used.add(p.toLowerCase());
    out.set(t.id, p);
  }
  return out;
}
var num = (n2, dp = 2) => n2 === null || n2 === void 0 || !isFinite(n2) ? null : Math.round(n2 * 10 ** dp) / 10 ** dp;
var money2 = (n2, cur) => {
  if (n2 === null || !isFinite(n2)) return "\u2014";
  let s;
  try {
    s = new Intl.NumberFormat("en-US", { style: "currency", currency: cur }).format(Math.abs(n2));
  } catch {
    s = Math.abs(n2).toFixed(2);
  }
  return (n2 < 0 ? "-" : n2 > 0 ? "+" : "") + s;
};
var rTxt = (r) => r === null || !isFinite(r) ? "\u2014" : `${r > 0 ? "+" : ""}${r.toFixed(2)}R`;
var price = (n2) => n2 === null || !isFinite(n2) ? "\u2014" : String(+n2.toFixed(6));
function localTime(iso, tz) {
  if (!iso || isNaN(Date.parse(iso))) return null;
  const p = {};
  new Intl.DateTimeFormat("en-GB", { timeZone: tz, hourCycle: "h23", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" }).formatToParts(new Date(iso)).forEach((x) => p[x.type] = x.value);
  return `${p.year}-${p.month}-${p.day} ${p.hour}:${p.minute}`;
}
var closeTime = (t) => {
  const exits = t.executions.filter((e) => e.kind === "exit").map((e) => e.time).sort();
  return exits.length ? exits[exits.length - 1] : null;
};
var tagName = (s) => s.trim().replace(/\s+/g, "-").replace(/[^\p{L}\p{N}_/-]/gu, "").replace(/^\d+$/, (d) => `n${d}`);
var clean = (s) => s.replace(MARKER_RE, "<!-- your notes (from LEDGR) -->").replace(/^---$/gm, "\u2014").trim();
var yamlScalar = (v) => {
  if (v === null || v === void 0) return "";
  if (typeof v === "number" || typeof v === "boolean") return String(v);
  return JSON.stringify(String(v));
};
function yamlBlock(o) {
  return Object.entries(o).map(([k, v]) => Array.isArray(v) ? v.length ? `${k}:
${v.map((x) => `  - ${yamlScalar(x)}`).join("\n")}` : `${k}: []` : `${k}: ${yamlScalar(v)}`).join("\n");
}
var TRADE_KEYS = ["id", "symbol", "direction", "qty", "entry", "exit", "net", "R", "setup", "account", "tags", "opened", "closed", "date", "status", "result", "ledgr"];
function tradeFrontmatter(t, c, deleted = false) {
  return {
    id: t.id,
    symbol: t.symbol,
    direction: t.direction ?? "",
    qty: num(t.quantity, 4),
    entry: num(t.entryPrice, 6),
    exit: num(t.exitPrice, 6),
    net: num(t.net),
    R: num(t.r),
    setup: setupOf(t),
    account: t.accountId && c.accounts[t.accountId] || "",
    tags: ["ledgr/trade", ...t.tags.map(tagName).filter(Boolean)],
    opened: localTime(t.openedAt, c.tz) ?? "",
    closed: localTime(closeTime(t), c.tz) ?? "",
    date: t.date,
    status: deleted ? "deleted in LEDGR" : t.status,
    result: t.result ?? "",
    ledgr: `https://www.ledgrjournal.app/journal/${t.id}`
  };
}
function tradeBody(t, c, deleted = false) {
  const P = paths(c.root), setup = setupOf(t), cur = c.currency;
  const pts = t.entryPrice !== null && t.exitPrice !== null ? (t.exitPrice - t.entryPrice) * (t.direction === "short" ? -1 : 1) : null;
  const opened = localTime(t.openedAt, c.tz), closed = localTime(closeTime(t), c.tz);
  const rows = [
    ["Result", t.status === "closed" ? `**${money2(t.net, cur)}** \xB7 ${rTxt(t.r)}${t.result ? ` \xB7 ${t.result}` : ""}` : t.status === "open" ? "Open" : "Draft"],
    ["Account", t.accountId && c.accounts[t.accountId] || "\u2014"],
    ["Size", `${t.quantity ?? "\u2014"} @ ${price(t.entryPrice)} \u2192 ${price(t.exitPrice)}${pts !== null ? ` (${+pts.toFixed(4)} pts)` : ""}`],
    ["Stop / target", `${price(t.stopPrice)} / ${price(t.targetPrice)}`],
    ["Opened \u2192 closed", `${opened ?? "\u2014"} \u2192 ${closed && opened && closed.slice(0, 10) === opened.slice(0, 10) ? closed.slice(11) : closed ?? "\u2014"}${t.durationMinutes ? ` (${t.durationMinutes} min)` : ""}`],
    ["Session", t.session ?? "\u2014"],
    ["Fees", money2(t.fees === null ? null : -t.fees, cur).replace(/^-/, "")],
    ["Grade \xB7 rating", `${t.grade ?? "\u2014"} \xB7 ${t.rating ? `${t.rating}/10` : "\u2014"}`]
  ];
  const links = [
    `**Day** ${link(P.day(t.date), t.date)}`,
    setup && `**Setup** ${link(P.setup(setup), setup)}`,
    t.mistakes.length && `**Mistakes** ${t.mistakes.map((m) => link(P.mistake(m), m)).join(", ")}`,
    t.tags.length && `**Tags** ${t.tags.map((x) => link(P.tag(x), x)).join(", ")}`
  ].filter(Boolean).join(" \xB7 ");
  const r = t.review, plan = r.followedPlan === "yes" ? "Yes" : r.followedPlan === "partial" ? "Partly" : r.followedPlan === "no" ? "No" : "\u2014";
  const field = (label, v) => v && v.trim() ? `**${label}**
${clean(v)}
` : "";
  const review = [field("What went well", r.wentWell), field("What went wrong", r.wentWrong), field("What to improve", r.improve), field("What I learned", r.learned)].filter(Boolean).join("\n");
  const notes = [field("Entry", t.notes.entry), field("Exit", t.notes.exit)].filter(Boolean).join("\n");
  return [
    `# ${t.symbol.toUpperCase()} ${dirWord(t.direction)}${setup ? ` \xB7 ${clean(setup)}` : ""}`,
    "",
    deleted ? "> [!warning] This trade was deleted in LEDGR. Your notes below are kept; delete this note yourself if you don't need it." : `> [!info] Synced from [LEDGR](https://www.ledgrjournal.app/journal/${t.id}). Edit the trade in LEDGR; write your own notes below the line.`,
    "",
    "| | |",
    "|---|---|",
    ...rows.map(([k, v]) => `| ${k} | ${v.replace(/\|/g, "\\|")} |`),
    "",
    links,
    "",
    "## Review",
    review || "_No review yet._",
    `**Followed plan** ${plan}`,
    ...t.emotions.length ? ["", `**Emotions** ${t.emotions.join(", ")}`] : [],
    ...notes ? ["", "## Trade notes", notes] : []
  ].join("\n").trim();
}
var summarise = (ts) => {
  const c = ts.filter((t) => t.status === "closed" && t.net !== null);
  const rs = c.map((t) => t.r).filter((r) => r !== null && isFinite(r));
  return { n: c.length, net: c.reduce((a, t) => a + (t.net ?? 0), 0), wins: c.filter((t) => (t.net ?? 0) > 0).length, losses: c.filter((t) => (t.net ?? 0) < 0).length, rSum: rs.reduce((a, b) => a + b, 0), rN: rs.length };
};
var statLine = (s, cur) => `**${money2(s.n ? s.net : null, cur)}** \xB7 ${s.n} closed trade${s.n === 1 ? "" : "s"} \xB7 win rate ${s.wins + s.losses ? Math.round(s.wins / (s.wins + s.losses) * 100) + "%" : "\u2014"} \xB7 avg ${s.rN ? rTxt(s.rSum / s.rN) : "\u2014"}`;
var tradeRow = (t, path, c) => {
  const time = localTime(t.openedAt, c.tz)?.slice(11) ?? "";
  return `- ${link(path, `${t.date}${time ? " " + time : ""} ${t.symbol.toUpperCase()} ${dirWord(t.direction)}`.trim())} \xB7 ${t.status === "closed" ? `${money2(t.net, c.currency)} \xB7 ${rTxt(t.r)}` : t.status}`;
};
function hubNotes(trades, notePath, c) {
  const P = paths(c.root), out = [];
  const group = (key) => {
    const m = /* @__PURE__ */ new Map();
    for (const t of trades) for (const k of key(t)) if (k) m.set(k, [...m.get(k) ?? [], t]);
    return m;
  };
  const list = (ts) => [...ts].sort((a, b) => b.date.localeCompare(a.date) || b.number - a.number).map((t) => tradeRow(t, notePath.get(t.id), c)).join("\n");
  for (const [day, ts] of group((t) => [t.date])) {
    const setups = [...new Set(ts.map(setupOf).filter(Boolean))];
    out.push({
      path: P.day(day),
      frontmatter: { date: day, trades: ts.length, net: num(summarise(ts).net), tags: ["ledgr/day"] },
      body: [`# ${day}`, "", statLine(summarise(ts), c.currency), "", "## Trades", list([...ts].reverse()), ...setups.length ? ["", `**Setups** ${setups.map((s) => link(P.setup(s), s)).join(", ")}`] : []].join("\n")
    });
  }
  const hub = (title, tag, path, m) => {
    for (const [k, ts] of m) out.push({ path: path(k), frontmatter: { [tag]: k, trades: ts.length, net: num(summarise(ts).net), tags: [`ledgr/${tag}`] }, body: [`# ${clean(k)}`, "", `${title} \xB7 ${statLine(summarise(ts), c.currency)}`, "", "## Trades", list(ts)].join("\n") });
  };
  hub("Setup", "setup", P.setup, group((t) => [setupOf(t)]));
  hub("Mistake", "mistake", P.mistake, group((t) => t.mistakes));
  hub("Tag", "tag", P.tag, group((t) => t.tags));
  return out;
}
var HUB_KEYS = ["date", "trades", "net", "tags", "setup", "mistake", "tag"];
function splitFrontmatter(text) {
  const m = text.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n?/);
  return m ? { fm: m[1], body: text.slice(m[0].length) } : { fm: null, body: text };
}
function yamlEntries(fm) {
  const out = [];
  for (const line of fm.split(/\r?\n/)) {
    const k = line.match(/^([^\s#:][^:]*):(\s|$)/);
    if (k) out.push({ key: k[1].trim(), text: line });
    else if (out.length) out[out.length - 1].text += "\n" + line;
    else out.push({ key: null, text: line });
  }
  return out;
}
function mergeNote(existing, managedKeys, fm, body, starter = "## My notes\n\n") {
  const managedFm = yamlBlock(fm);
  if (existing === null) return `---
${managedFm}
---
${body}

${MARKER}
${starter}`;
  const { fm: oldFm, body: oldBody } = splitFrontmatter(existing);
  const keep = oldFm ? yamlEntries(oldFm).filter((e) => e.key === null ? e.text.trim() !== "" : !managedKeys.includes(e.key)).map((e) => e.text) : [];
  const idx = oldBody.search(MARKER_RE);
  const mine = idx >= 0 ? oldBody.slice(idx).replace(MARKER_RE, "").replace(/^\r?\n/, "") : `
${oldBody.trim()}
`;
  return `---
${[managedFm, ...keep].join("\n")}
---
${body}

${MARKER}
${mine}`;
}

// src/notes/starter.ts
var REGION_START = "<!-- ledgr:start -->";
var REGION_END = "<!-- ledgr:end -->";
var PARA = ["Projects", "Areas", "Resources", "Archive"];
var homePath = (root) => `${root}/Home.md`;
var templatePath = (root) => `${root}/Templates/Daily trading note.md`;
function replaceRegion(text, content) {
  const a = text.indexOf(REGION_START), b = text.indexOf(REGION_END);
  if (a < 0 || b < a) return null;
  return text.slice(0, a + REGION_START.length) + "\n" + content.trim() + "\n" + text.slice(b);
}
var money3 = (n2, cur) => {
  try {
    return (n2 < 0 ? "-" : n2 > 0 ? "+" : "") + new Intl.NumberFormat("en-US", { style: "currency", currency: cur }).format(Math.abs(n2));
  } catch {
    return n2.toFixed(2);
  }
};
function homeRegion(trades, notePath, c, today) {
  const P = paths(c.root);
  const closed = trades.filter((t) => t.status === "closed" && t.net !== null);
  const since = (days) => {
    const d = /* @__PURE__ */ new Date(today + "T00:00:00Z");
    d.setUTCDate(d.getUTCDate() - days);
    return d.toISOString().slice(0, 10);
  };
  const sum = (ts) => ts.reduce((a, t) => a + (t.net ?? 0), 0);
  const week = closed.filter((t) => t.date >= since(6)), month = closed.filter((t) => t.date >= since(29));
  const recent = [...closed].sort((a, b) => b.date.localeCompare(a.date) || b.number - a.number).slice(0, 8);
  const bySetup = /* @__PURE__ */ new Map();
  closed.forEach((t) => {
    const s = setupOf(t);
    if (s) bySetup.set(s, (bySetup.get(s) ?? 0) + (t.net ?? 0));
  });
  const ranked = [...bySetup].sort((a, b) => b[1] - a[1]);
  return [
    `**Last 7 days** ${money3(sum(week), c.currency)} \xB7 ${week.length} trades  \xB7  **Last 30 days** ${money3(sum(month), c.currency)} \xB7 ${month.length} trades`,
    "",
    "**Recent trades**",
    ...recent.length ? recent.map((t) => `- ${link(notePath.get(t.id), `${t.date} ${t.symbol.toUpperCase()} ${t.direction ?? ""}`.trim())} \xB7 ${money3(t.net ?? 0, c.currency)}`) : ["- No trades yet."],
    "",
    ...ranked.length ? [`**Best setup** ${link(P.setup(ranked[0][0]), ranked[0][0])} ${money3(ranked[0][1], c.currency)}${ranked.length > 1 ? ` \xB7 **Worst setup** ${link(P.setup(ranked[ranked.length - 1][0]), ranked[ranked.length - 1][0])} ${money3(ranked[ranked.length - 1][1], c.currency)}` : ""}`, ""] : [],
    `Today: ${link(P.day(today), today)} \xB7 Your trades are in the ${c.root}/Trades, Days and Setups folders.`,
    "",
    `_Updated by LEDGR on sync. Open the Command Center from the pulse icon in the ribbon._`
  ].join("\n");
}
function homeNote(region) {
  return `---
tags:
  - ledgr/home
---
# Trading Home

${REGION_START}
${region}
${REGION_END}

## Focus this week
-

## Rules I trade by
1.

## Areas
- [[Projects]] \xB7 [[Areas]] \xB7 [[Resources]] \xB7 [[Archive]]
`;
}
function dailyTemplate(root) {
  return `---
date: {{date}}
tags:
  - ledgr/daily
---
# {{date}}

Day in LEDGR: [[${root}/Days/{{date}}|{{date}}]]

## Before the open
- Bias:
- Key levels:
- News to avoid:
- Max loss today:

## Checklist
- [ ] Higher-timeframe bias marked
- [ ] Key levels drawn
- [ ] Setup is in my playbook
- [ ] Stop and target set before entry
- [ ] Size from the calculator, not a guess
- [ ] Calm, not chasing or revenge trading

## After the close
- What went well:
- What went wrong:
- What to improve:
- Sleep \xB7 focus \xB7 energy (1\u201310):
`;
}

// src/notes/sync.ts
async function ensureFolder(app, path) {
  const parts = (0, import_obsidian2.normalizePath)(path).split("/");
  for (let i = 1; i <= parts.length; i++) {
    const p = parts.slice(0, i).join("/");
    if (!app.vault.getAbstractFileByPath(p)) await app.vault.createFolder(p).catch(() => void 0);
  }
}
function findTradeNotes(app) {
  const out = /* @__PURE__ */ new Map();
  for (const f of app.vault.getMarkdownFiles()) {
    const fm = app.metadataCache.getFileCache(f)?.frontmatter;
    if (fm && typeof fm.id === "string" && typeof fm.ledgr === "string" && fm.ledgr.startsWith("https://www.ledgrjournal.app/journal/")) out.set(fm.id, f);
  }
  return out;
}
async function write(app, path, next, r) {
  const p = (0, import_obsidian2.normalizePath)(path);
  const f = app.vault.getAbstractFileByPath(p);
  if (f instanceof import_obsidian2.TFile) {
    const old = await app.vault.read(f);
    const text = next(old);
    if (text === old) {
      r.unchanged++;
      return;
    }
    await app.vault.modify(f, text);
    r.updated++;
  } else {
    await ensureFolder(app, p.split("/").slice(0, -1).join("/"));
    await app.vault.create(p, next(null));
    r.created++;
  }
}
async function syncNotes(app, trades, c, today) {
  const r = { created: 0, updated: 0, unchanged: 0, deleted: 0, trades: trades.length };
  const found = findTradeNotes(app);
  const existing = new Map(Array.from(found, ([id, f]) => [id, f.path]));
  const taken = new Set(app.vault.getFiles().map((f) => f.path));
  const notePath = assignPaths(trades, existing, taken, c.root);
  for (const folder of Object.values(paths(c.root)).filter((v) => typeof v === "string")) await ensureFolder(app, folder);
  for (const t of trades) {
    await write(app, notePath.get(t.id), (old) => mergeNote(old, TRADE_KEYS, tradeFrontmatter(t, c), tradeBody(t, c)), r);
  }
  const ids = new Set(trades.map((t) => t.id));
  for (const [id, f] of found) {
    if (ids.has(id)) continue;
    let changed = false;
    await app.fileManager.processFrontMatter(f, (fm) => {
      if (fm.status !== "deleted in LEDGR") {
        fm.status = "deleted in LEDGR";
        changed = true;
      }
    });
    if (changed) r.deleted++;
  }
  for (const h of hubNotes(trades, notePath, c)) await write(app, h.path, (old) => mergeNote(old, HUB_KEYS, h.frontmatter, h.body, ""), r);
  const home = app.vault.getAbstractFileByPath((0, import_obsidian2.normalizePath)(homePath(c.root)));
  if (home instanceof import_obsidian2.TFile) {
    const old = await app.vault.read(home);
    const text = replaceRegion(old, homeRegion(trades, notePath, c, today));
    if (text !== null && text !== old) await app.vault.modify(home, text);
  }
  return r;
}
async function createStarter(app, trades, c, today) {
  const made = [];
  for (const p of PARA) if (!app.vault.getAbstractFileByPath(p)) {
    await app.vault.createFolder(p).catch(() => void 0);
    made.push(`${p}/`);
  }
  const notePath = assignPaths(trades, new Map(Array.from(findTradeNotes(app), ([id, f]) => [id, f.path])), new Set(app.vault.getFiles().map((f) => f.path)), c.root);
  for (const [path, text] of [[homePath(c.root), homeNote(homeRegion(trades, notePath, c, today))], [templatePath(c.root), dailyTemplate(c.root)]]) {
    const p = (0, import_obsidian2.normalizePath)(path);
    if (app.vault.getAbstractFileByPath(p)) continue;
    await ensureFolder(app, p.split("/").slice(0, -1).join("/"));
    await app.vault.create(p, text);
    made.push(p);
  }
  return made;
}

// src/view.ts
var import_obsidian3 = require("obsidian");

// src/cc/calendarText.ts
function calendarText(s) {
  if (s.kind === "error") return {
    ticker: "ECONOMIC CALENDAR \xB7 OFFLINE \xB7 couldn't load this week's events",
    list: `Couldn't load the calendar: ${s.message}`,
    checklist: " (calendar offline)"
  };
  return {
    ticker: "ECONOMIC CALENDAR \xB7 NOT CONNECTED YET",
    list: "The economic calendar isn't connected yet. It will load here from LEDGR once it's available.",
    checklist: " (calendar not connected)"
  };
}

// src/cc/canvas/fit.ts
var winOf = (el) => el.ownerDocument.defaultView ?? window;
function fit(cv, heightOverride) {
  const p = cv.parentElement, win = winOf(cv), cs = win.getComputedStyle(p), dpr = Math.min(2, win.devicePixelRatio || 1);
  const px = (v) => parseFloat(v) || 0;
  const r = { height: p.offsetHeight };
  const inner = p.clientWidth - px(cs.paddingLeft) - px(cs.paddingRight);
  if (cv.dataset.h === void 0) cv.dataset.h = cv.dataset.flex ? "" : cv.getAttribute("height") ?? "";
  const h = cv.dataset.h ? +cv.dataset.h : Math.max(120, r.height - (cv.offsetTop - p.offsetTop) - (cv.nextElementSibling ? 60 : 12));
  const w = Math.max(100, Math.floor(inner));
  if (heightOverride !== void 0) return size(cv, w, heightOverride, dpr);
  return size(cv, w, h, dpr);
}
function size(cv, w, h, dpr) {
  if (cv._w !== w || cv._h !== h) {
    cv._w = w;
    cv._h = h;
    cv.width = w * dpr;
    cv.height = h * dpr;
    cv.style.width = w + "px";
    cv.style.height = h + "px";
  }
  const g = cv.getContext("2d");
  g.setTransform(dpr, 0, 0, dpr, 0, 0);
  return { g, w, h };
}
function cvFit(cv) {
  const dpr = Math.min(2, winOf(cv).devicePixelRatio || 1), r = { width: cv.clientWidth, height: cv.clientHeight };
  if (cv.width !== Math.round(r.width * dpr) || cv.height !== Math.round(r.height * dpr)) {
    cv.width = r.width * dpr;
    cv.height = r.height * dpr;
  }
  const g = cv.getContext("2d");
  g.setTransform(dpr, 0, 0, dpr, 0, 0);
  return { g, w: r.width, h: r.height };
}
function seeded(seed = 11) {
  let s = seed;
  const rnd = () => (s = s * 16807 % 2147483647) / 2147483647;
  const gauss = () => {
    const u = rnd() || 1e-9, v = rnd();
    return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  };
  const unit = () => {
    const z = rnd() * 2 - 1, a = rnd() * 6.283, r = Math.sqrt(1 - z * z);
    return [r * Math.cos(a), z, r * Math.sin(a)];
  };
  return { rnd, gauss, unit };
}
function rot(p, ay, ax) {
  const cy = Math.cos(ay), sy = Math.sin(ay), cx = Math.cos(ax), sx = Math.sin(ax);
  const x = p[0] * cy + p[2] * sy;
  let z = -p[0] * sy + p[2] * cy;
  const y = p[1] * cx - z * sx;
  z = p[1] * sx + z * cx;
  return [x, y, z];
}
var RED = "255,255,255";
var scaleOf = (el) => el.offsetWidth ? el.getBoundingClientRect().width / el.offsetWidth : 1;

// src/cc/canvas/charts.ts
function lineChart(cv, vals, labels) {
  const { g, w, h } = fit(cv);
  g.clearRect(0, 0, w, h);
  if (vals.length < 2) {
    g.fillStyle = "#c2c2c2";
    g.font = "12px 'Share Tech Mono',monospace";
    g.fillText("AWAITING DATA", 12, 24);
    return;
  }
  const mn = Math.min(0, ...vals), mx = Math.max(0, ...vals), rg = mx - mn || 1, X = (i) => 8 + (w - 16) * i / (vals.length - 1), Y = (v) => 6 + (h - 24) * (1 - (v - mn) / rg);
  g.strokeStyle = "rgba(122,122,122,.6)";
  for (let k = 0; k <= 4; k++) {
    const y = 6 + (h - 24) * k / 4;
    g.beginPath();
    g.moveTo(0, y);
    g.lineTo(w, y);
    g.stroke();
  }
  g.setLineDash([3, 3]);
  g.beginPath();
  g.moveTo(0, Y(0));
  g.lineTo(w, Y(0));
  g.stroke();
  g.setLineDash([]);
  const gr = g.createLinearGradient(0, 0, 0, h);
  gr.addColorStop(0, "rgba(255,255,255,.35)");
  gr.addColorStop(1, "rgba(255,255,255,0)");
  g.fillStyle = gr;
  g.beginPath();
  vals.forEach((v, i) => i ? g.lineTo(X(i), Y(v)) : g.moveTo(X(i), Y(v)));
  g.lineTo(X(vals.length - 1), Y(mn));
  g.lineTo(X(0), Y(mn));
  g.fill();
  g.strokeStyle = "#ffffff";
  g.shadowColor = "#ffffff";
  g.shadowBlur = 8;
  g.lineWidth = 1.6;
  g.beginPath();
  vals.forEach((v, i) => i ? g.lineTo(X(i), Y(v)) : g.moveTo(X(i), Y(v)));
  g.stroke();
  g.shadowBlur = 0;
  if (labels) {
    g.fillStyle = "#c2c2c2";
    g.font = "10px 'Share Tech Mono',monospace";
    g.textAlign = "left";
    g.fillText(labels[0], 4, h - 4);
    g.textAlign = "right";
    g.fillText(labels[1], w - 4, h - 4);
    g.fillText(smoney(vals[vals.length - 1]), w - 4, 14);
  }
}
function barChart(cv, rows) {
  const { g, w, h } = fit(cv);
  g.clearRect(0, 0, w, h);
  if (!rows.length) {
    g.fillStyle = "#c2c2c2";
    g.font = "12px 'Share Tech Mono',monospace";
    g.fillText("AWAITING DATA", 12, 24);
    return;
  }
  const bh = Math.min(26, (h - 10) / rows.length - 6), m = Math.max(1, ...rows.map((r) => Math.abs(r.v))), L = 110, mid = L + (w - L - 80) / 2, sc = (w - L - 80) / 2 / m;
  g.font = "11px 'Share Tech Mono',monospace";
  rows.forEach((r, i) => {
    const y = 6 + i * (bh + 6);
    g.fillStyle = "#ffffff";
    g.textAlign = "left";
    g.fillText(r.k.slice(0, 14), 0, y + bh * 0.7);
    const bw = Math.abs(r.v) * sc;
    g.fillStyle = r.v >= 0 ? "rgba(60,255,143,.75)" : "rgba(255,255,255,.85)";
    g.shadowColor = g.fillStyle;
    g.shadowBlur = 6;
    g.fillRect(r.v >= 0 ? mid : mid - bw, y, Math.max(1, bw), bh);
    g.shadowBlur = 0;
    g.fillStyle = r.v >= 0 ? "#3cff8f" : "#ff5a4f";
    g.textAlign = "right";
    g.fillText(smoney(r.v).replace(".00", ""), w, y + bh * 0.7);
  });
  g.strokeStyle = "rgba(255,255,255,.3)";
  g.beginPath();
  g.moveTo(mid, 0);
  g.lineTo(mid, h);
  g.stroke();
}

// src/cc/canvas/brain.ts
var NODES = [
  ["PSYCHE", [-0.55, 0.45, 0.55]],
  ["STRATEGY", [0.6, 0.4, 0.45]],
  ["RULES", [0, 0.7, 0]],
  ["PERFORMANCE", [0.75, 0.05, -0.55]],
  ["RISK", [-0.8, 0, -0.4]],
  ["LEARNING", [-0.3, 0.25, 1.2]],
  ["BODY", [0, -1.1, -0.45]]
];
function createBrain(cv, chips, life, tip) {
  const { rnd, gauss, unit } = seeded(11);
  const B = { pts: [], ay: 0, ax: -0.15, drag: null, labels: {}, proj: [], focus: null };
  for (let i = 0; i < 5200; i++) {
    const d = unit(), side = d[0] < 0 ? -1 : 1, rr = Math.pow(rnd(), 0.25), fold = 1 + 0.07 * Math.sin(d[1] * 13 + d[2] * 9) * Math.cos(d[0] * 11);
    let x = d[0] * 1.05 * rr * fold, y = d[1] * 0.78 * rr * fold;
    const z = d[2] * 1.35 * rr * fold;
    x += side * 0.06;
    if (y < -0.35) y = -0.35 + (y + 0.35) * 0.35;
    B.pts.push([x, y, z]);
  }
  for (let i = 0; i < 900; i++) {
    const d = unit(), rr = Math.pow(rnd(), 0.35);
    B.pts.push([d[0] * 0.55 * rr, -0.5 + d[1] * 0.25 * rr, -0.85 + d[2] * 0.38 * rr]);
  }
  for (let i = 0; i < 500; i++) {
    const t = rnd();
    B.pts.push([gauss() * 0.06, -0.4 - t * 0.9, -0.35 - t * 0.15 + gauss() * 0.05]);
  }
  const SYN = { n: [], e: [], p: [] };
  const pick = [];
  for (let i = 0; i < 180; i++) pick.push(B.pts[Math.random() * 5200 | 0]);
  SYN.n = pick;
  pick.forEach((a, i) => {
    const d = pick.map((b, j) => [j, (a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2 + (a[2] - b[2]) ** 2]).filter((x) => x[0] !== i).sort((x, y) => x[1] - y[1]).slice(0, 2);
    d.forEach(([j]) => {
      if (i < j) SYN.e.push([i, j]);
    });
  });
  let hoverNode = null;
  life.on(cv, "pointerdown", (e) => {
    B.drag = [e.clientX, e.clientY];
  });
  life.on(life.win, "pointerup", () => {
    B.drag = null;
  });
  life.on(life.win, "pointermove", (e) => {
    if (!B.drag) return;
    B.ay += (e.clientX - B.drag[0]) * 8e-3;
    B.ax = Math.max(-1, Math.min(1, B.ax + (e.clientY - B.drag[1]) * 6e-3));
    B.drag = [e.clientX, e.clientY];
  });
  life.on(cv, "mousemove", (e) => {
    const b = cv.getBoundingClientRect(), k = scaleOf(cv);
    const hit = B.proj.filter((n2) => Math.hypot((e.clientX - b.left) / k - n2.x, (e.clientY - b.top) / k - n2.y) < 16).pop() ?? null;
    hoverNode = hit;
    if (hit) tip.show(e, `<b>${esc(hit.k)}</b><br>${esc(B.labels[hit.k] || "")}`);
    else tip.hide();
  });
  life.on(cv, "mouseleave", () => tip.hide());
  chips.empty();
  for (const [k] of NODES) {
    const c = chips.createSpan({ cls: "chip", text: k });
    c.dataset.n = k;
    c.onmouseenter = () => {
      B.focus = k;
    };
    c.onmouseleave = () => {
      B.focus = null;
    };
  }
  function draw(t) {
    const { g, w, h } = fit(cv);
    g.clearRect(0, 0, w, h);
    const sc = Math.min(w, h) * 0.33, cx = w * 0.5, cy = h * 0.46;
    if (!B.drag) B.ay += 3e-3;
    g.globalCompositeOperation = "lighter";
    const P = SYN.n.map((p) => {
      const q = rot(p, B.ay, B.ax);
      return [cx + q[0] * sc, cy - q[1] * sc, (q[2] + 1.5) / 3];
    });
    g.lineWidth = 0.6;
    g.strokeStyle = "rgba(255,255,255,.07)";
    g.beginPath();
    for (const [a, b] of SYN.e) {
      g.moveTo(P[a][0], P[a][1]);
      g.lineTo(P[b][0], P[b][1]);
    }
    g.stroke();
    if (Math.random() < 0.35 && SYN.p.length < 40) SYN.p.push({ e: SYN.e[Math.random() * SYN.e.length | 0], t: 0, rev: Math.random() < 0.5 });
    SYN.p = SYN.p.filter((q) => (q.t += 0.035) < 1);
    for (const q of SYN.p) {
      let [a, b] = q.e;
      if (q.rev) [a, b] = [b, a];
      const A = P[a], Bp = P[b], x = A[0] + (Bp[0] - A[0]) * q.t, y = A[1] + (Bp[1] - A[1]) * q.t;
      g.strokeStyle = `rgba(255,255,255,${(0.35 * (1 - q.t)).toFixed(2)})`;
      g.lineWidth = 1;
      g.beginPath();
      g.moveTo(A[0], A[1]);
      g.lineTo(x, y);
      g.stroke();
      g.fillStyle = "rgba(255,255,255,.95)";
      g.beginPath();
      g.arc(x, y, 1.8, 0, 7);
      g.fill();
      const gl = g.createRadialGradient(x, y, 0, x, y, 10);
      gl.addColorStop(0, "rgba(255,255,255,.35)");
      gl.addColorStop(1, "rgba(255,255,255,0)");
      g.fillStyle = gl;
      g.fillRect(x - 10, y - 10, 20, 20);
    }
    for (const p of B.pts) {
      const q = rot(p, B.ay, B.ax), z = (q[2] + 1.5) / 3, x = cx + q[0] * sc, y = cy - q[1] * sc, fl = 0.35 + 0.65 * z;
      g.fillStyle = `rgba(${RED},${(0.25 + 0.55 * fl).toFixed(2)})`;
      g.fillRect(x, y, 1.4 + fl * 0.9, 1.4 + fl * 0.9);
    }
    const pulse = (Math.sin(t * 4e-3) + 1) / 2;
    g.globalCompositeOperation = "source-over";
    B.proj = [];
    NODES.forEach(([k, p]) => {
      const q = rot(p, B.ay, B.ax), x = cx + q[0] * sc, y = cy - q[1] * sc, front = q[2] > -0.3, lx = x + (x > cx ? 60 : -60), ly = y - 18;
      B.proj.push({ k, x, y });
      const hi = B.focus === k || hoverNode && hoverNode.k === k;
      g.strokeStyle = `rgba(${RED},${front ? 0.8 : 0.3})`;
      g.lineWidth = 1;
      g.beginPath();
      g.moveTo(x, y);
      g.lineTo(lx, ly);
      g.lineTo(lx + (x > cx ? 50 : -50), ly);
      g.stroke();
      g.fillStyle = hi ? "#ffffff" : `rgba(255,255,255,${front ? 1 : 0.4})`;
      g.beginPath();
      g.arc(x, y, hi ? 5 : 3 + pulse * 1.5, 0, 7);
      g.fill();
      g.font = "11px 'Share Tech Mono',monospace";
      g.textAlign = x > cx ? "left" : "right";
      g.fillStyle = hi ? "#ffffff" : `rgba(255,255,255,${front ? 0.95 : 0.45})`;
      g.fillText(k, lx + (x > cx ? 4 : -4), ly - 4);
      if (hi || front) {
        g.fillStyle = `rgba(194,194,194,${front ? 0.9 : 0.4})`;
        g.font = "10px 'Share Tech Mono',monospace";
        g.fillText((B.labels[k] || "").slice(0, 34), lx + (x > cx ? 4 : -4), ly + 9);
      }
    });
    const sy = t * 0.08 % h;
    g.fillStyle = `rgba(${RED},.08)`;
    g.fillRect(0, sy, w, 2);
  }
  return { draw, setLabels: (l) => {
    B.labels = l;
  } };
}

// src/cc/canvas/figure.ts
function createFigure(cv, video, life) {
  return function draw(t) {
    const r = { width: cv.parentElement.clientWidth, height: cv.parentElement.clientHeight }, dpr = Math.min(2, winOf(cv).devicePixelRatio || 1), w = r.width, h = r.height;
    if (w < 10) return;
    if (cv.width !== Math.round(w * dpr) || cv.height !== Math.round(h * dpr)) {
      cv.width = w * dpr;
      cv.height = h * dpr;
    }
    const g = cv.getContext("2d");
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.clearRect(0, 0, w, h);
    if (video.paused && video.readyState >= 2) video.play().catch(() => void 0);
    const by = (t * 22e-5 % 1.2 - 0.1) * h;
    const gr = g.createLinearGradient(0, by - 18, 0, by + 18);
    gr.addColorStop(0, "rgba(255,255,255,0)");
    gr.addColorStop(0.5, "rgba(255,255,255,.20)");
    gr.addColorStop(1, "rgba(255,255,255,0)");
    g.fillStyle = gr;
    g.fillRect(0, by - 18, w, 36);
    for (let y = 0; y < h; y += 3) {
      g.fillStyle = "rgba(0,0,0,.16)";
      g.fillRect(0, y, w, 1);
    }
    if (Math.random() < 0.015) {
      video.style.transform = `translateX(${(Math.random() - 0.5) * 10}px)`;
      video.style.filter = "grayscale(1) contrast(1.25) brightness(1.35)";
      life.after(70, () => {
        video.style.transform = "";
        video.style.filter = "";
      });
    }
    g.strokeStyle = "rgba(255,255,255,.55)";
    g.lineWidth = 1;
    const m = 6, L = 14;
    [[m, m, 1, 1], [w - m, m, -1, 1], [m, h - m, 1, -1], [w - m, h - m, -1, -1]].forEach(([x, y, sx, sy]) => {
      g.beginPath();
      g.moveTo(x, y + sy * L);
      g.lineTo(x, y);
      g.lineTo(x + sx * L, y);
      g.stroke();
    });
  };
}

// src/cc/market.ts
function etParts(now = /* @__PURE__ */ new Date()) {
  const f = new Intl.DateTimeFormat("en-US", { timeZone: "America/New_York", weekday: "short", hour: "numeric", minute: "numeric", hour12: false }).formatToParts(now);
  const o = {};
  f.forEach((p) => o[p.type] = p.value);
  return { d: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].indexOf(o.weekday), h: +o.hour % 24 + +o.minute / 60 };
}
function cmeOpen(now = /* @__PURE__ */ new Date()) {
  const { d, h } = etParts(now);
  if (d === 6) return false;
  if (d === 0) return h >= 18;
  if (d === 5) return h < 17;
  return !(h >= 17 && h < 18);
}
function cmeNext(now = /* @__PURE__ */ new Date()) {
  const { d, h } = etParts(now);
  let mins;
  if (cmeOpen(now)) {
    mins = ((d === 5 ? 17 : h < 17 ? 17 : 41) - h) * 60;
    if (d !== 5 && h >= 18) mins = (24 - h + 17) * 60;
    return "Daily break in " + fmtDur(mins);
  }
  if (d === 6 || d === 5 && h >= 17) mins = (d === 5 ? 24 - h + 24 + 18 : 24 - h + 18) * 60;
  else mins = (18 - h) * 60;
  return "Opens in " + fmtDur(mins);
}

// src/cc/canvas/globe.ts
var LAND = [[50, 10, 22, 40], [8, 20, 28, 22], [55, 90, 22, 60], [25, 78, 10, 12], [35, 105, 12, 18], [45, -100, 18, 38], [62, -110, 10, 40], [-15, -60, 25, 15], [-25, 135, 12, 18], [72, -40, 7, 15], [0, 115, 6, 15], [37, 138, 5, 4], [54, -2, 4, 3], [64, 15, 6, 8]];
var GL = [];
for (let la = -80; la <= 80; la += 3.2)
  for (let lo = -180; lo < 180; lo += 3.2 / Math.max(0.25, Math.cos(la * Math.PI / 180)))
    if (LAND.some(([a, b, ra, rb]) => ((la - a) / ra) ** 2 + (((lo - b + 540) % 360 - 180) / rb) ** 2 < 1)) GL.push([la, lo]);
var ll = (la, lo, a) => {
  const p = la * Math.PI / 180, l = lo * Math.PI / 180 + a;
  return [Math.cos(p) * Math.sin(l), Math.sin(p), Math.cos(p) * Math.cos(l)];
};
function createGlobe(cv, tz) {
  let globeA = 0, cachedTz = "", CITIES = [];
  const cities = () => {
    const z = tz();
    if (z !== cachedTz) {
      cachedTz = z;
      const base = [["TOKYO", 35.7, 139.7, [0, 6]], ["LONDON", 51.5, -0.1, [7, 15.5]], ["NEW YORK", 40.7, -74, [13.5, 20]], ["CHICAGO \xB7 CME", 41.9, -87.6, [-1, 24]]];
      const xy = TZXY[z];
      CITIES = xy ? base.concat([[cityOf(z), xy[0], xy[1], [5, 13]]]) : base;
    }
    return CITIES;
  };
  return function draw(t) {
    const { g, w, h } = fit(cv);
    const C = cities();
    g.clearRect(0, 0, w, h);
    globeA += 25e-4;
    const R = Math.min(w, h) * 0.38, cx = w / 2, cy = h * 0.47, tilt = -0.35;
    const gr = g.createRadialGradient(cx - R * 0.3, cy - R * 0.3, R * 0.1, cx, cy, R);
    gr.addColorStop(0, "rgba(255,255,255,.55)");
    gr.addColorStop(1, "rgba(120,120,120,.25)");
    g.fillStyle = gr;
    g.beginPath();
    g.arc(cx, cy, R, 0, 7);
    g.fill();
    g.strokeStyle = `rgba(${RED},.7)`;
    g.lineWidth = 1.2;
    g.beginPath();
    g.arc(cx, cy, R, 0, 7);
    g.stroke();
    const rim = g.createRadialGradient(cx, cy, R * 0.92, cx, cy, R * 1.25);
    rim.addColorStop(0, "rgba(255,255,255,.18)");
    rim.addColorStop(1, "rgba(255,255,255,0)");
    g.fillStyle = rim;
    g.beginPath();
    g.arc(cx, cy, R * 1.25, 0, 7);
    g.arc(cx, cy, R, 0, 7, true);
    g.fill();
    g.fillStyle = "rgba(255,255,255,.22)";
    for (let la = -60; la <= 60; la += 30) for (let lo = -180; lo < 180; lo += 4) {
      const p = rot(ll(la, lo, globeA), 0, tilt);
      if (p[2] > 0) g.fillRect(cx + p[0] * R, cy - p[1] * R, 1, 1);
    }
    for (let lo = -180; lo < 180; lo += 30) for (let la = -80; la <= 80; la += 4) {
      const p = rot(ll(la, lo, globeA), 0, tilt);
      if (p[2] > 0) g.fillRect(cx + p[0] * R, cy - p[1] * R, 1, 1);
    }
    const ARC = [[0, 1], [1, 2], [2, 3], [4, 1], [0, 4]], ph = t * 25e-5 % 1;
    ARC.forEach(([a, b], k) => {
      const A = C[a], B = C[b];
      if (!A || !B) return;
      const va = ll(A[1], A[2], 0), vb = ll(B[1], B[2], 0);
      const om = Math.acos(Math.max(-1, Math.min(1, va[0] * vb[0] + va[1] * vb[1] + va[2] * vb[2]))) || 1e-3;
      const pt = (f2) => {
        const s1 = Math.sin((1 - f2) * om) / Math.sin(om), s2 = Math.sin(f2 * om) / Math.sin(om);
        const v = [va[0] * s1 + vb[0] * s2, va[1] * s1 + vb[1] * s2, va[2] * s1 + vb[2] * s2];
        const lift = 1 + 0.22 * Math.sin(Math.PI * f2);
        const lat = Math.asin(v[1] / Math.hypot(...v)), lon = Math.atan2(v[0], v[2]);
        const p = rot(ll(lat * 180 / Math.PI, lon * 180 / Math.PI, globeA), 0, tilt);
        return [cx + p[0] * R * lift, cy - p[1] * R * lift, p[2]];
      };
      g.lineWidth = 1;
      g.strokeStyle = "rgba(255,255,255,.28)";
      g.beginPath();
      let pen = false;
      for (let i = 0; i <= 40; i++) {
        const q2 = pt(i / 40);
        if (q2[2] > -0.15) {
          if (pen) g.lineTo(q2[0], q2[1]);
          else g.moveTo(q2[0], q2[1]);
          pen = true;
        } else pen = false;
      }
      g.stroke();
      const f = (ph + k * 0.2) % 1, q = pt(f);
      if (q[2] > -0.15) {
        g.fillStyle = "#fff";
        g.beginPath();
        g.arc(q[0], q[1], 2.4, 0, 7);
        g.fill();
        const gl = g.createRadialGradient(q[0], q[1], 0, q[0], q[1], 12);
        gl.addColorStop(0, "rgba(255,255,255,.5)");
        gl.addColorStop(1, "rgba(255,255,255,0)");
        g.fillStyle = gl;
        g.fillRect(q[0] - 12, q[1] - 12, 24, 24);
      }
    });
    for (const [la, lo] of GL) {
      const p = rot(ll(la, lo, globeA), 0, tilt);
      if (p[2] < 0) continue;
      g.fillStyle = `rgba(255,255,255,${0.35 + 0.6 * p[2]})`;
      g.fillRect(cx + p[0] * R - 1, cy - p[1] * R - 1, 2, 2);
    }
    const now = /* @__PURE__ */ new Date(), utc = now.getUTCHours() + now.getUTCMinutes() / 60;
    g.font = "11px 'Share Tech Mono',monospace";
    C.forEach(([n2, la, lo, [s, e]]) => {
      const p = rot(ll(la, lo, globeA), 0, tilt), open = n2.startsWith("CHICAGO") ? cmeOpen() : utc >= s && utc < e, x = cx + p[0] * R, y = cy - p[1] * R, vis = p[2] > 0;
      const pr = (Math.sin(t * 5e-3) + 1) / 2;
      g.globalAlpha = vis ? 1 : 0.25;
      g.fillStyle = open ? "#ffffff" : "#777777";
      g.beginPath();
      g.arc(x, y, 3.5, 0, 7);
      g.fill();
      if (open && vis) {
        g.strokeStyle = `rgba(255,255,255,${1 - pr})`;
        g.beginPath();
        g.arc(x, y, 4 + pr * 12, 0, 7);
        g.stroke();
      }
      const dy = n2.startsWith("CHICAGO") ? 40 : -16, lx = x + (p[0] > 0 ? 28 : -28) + (n2.startsWith("CHICAGO") ? p[0] > 0 ? 10 : -10 : 0);
      g.strokeStyle = "rgba(255,255,255,.7)";
      g.beginPath();
      g.moveTo(x, y);
      g.lineTo(lx, y + dy);
      g.stroke();
      g.textAlign = p[0] > 0 ? "left" : "right";
      g.fillStyle = "#ffffff";
      g.fillText(n2, lx + (p[0] > 0 ? 3 : -3), y + dy - 3);
      g.fillStyle = open ? "#ffffff" : "#c2c2c2";
      g.fillText(open ? "OPEN" : "CLOSED", lx + (p[0] > 0 ? 3 : -3), y + dy + 9);
      g.globalAlpha = 1;
    });
    g.strokeStyle = `rgba(${RED},.35)`;
    g.beginPath();
    g.ellipse(cx, cy, R * 1.25, R * 0.32, -0.2, 0, 7);
    g.stroke();
    const oa = t * 6e-4;
    g.fillStyle = "#ffffff";
    g.beginPath();
    g.arc(cx + Math.cos(oa) * R * 1.25 * Math.cos(-0.2) - Math.sin(oa) * R * 0.32 * Math.sin(-0.2), cy + Math.cos(oa) * R * 1.25 * Math.sin(-0.2) + Math.sin(oa) * R * 0.32 * Math.cos(-0.2), 2.5, 0, 7);
    g.fill();
    g.fillStyle = "#c2c2c2";
    g.textAlign = "left";
    g.fillText("DRAG-FREE ORBIT \xB7 LIVE SESSION STATUS", 12, h - 8);
  };
}

// src/cc/canvas/intro.ts
var clamp = (v) => Math.max(0, Math.min(1, v));
var eout = (v) => 1 - Math.pow(1 - clamp(v), 3);
var CH = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789#$%&@";
var TL = { log: 0, warp: 1.6, flash: 3.9, reveal: 4.25, title: 5.1, stats: 5.6, msg: 7.4, fly: 8.6, end: 9.6 };
function createIntro(d) {
  const { $, life, sound } = d;
  const S_ = sound.fx;
  let booting = false, bootT0 = null, fired = {};
  let WARP = null;
  const once = (key, fn) => {
    if (!fired[key]) {
      fired[key] = 1;
      fn();
    }
  };
  const boot = () => $("boot"), gate = () => $("gate");
  function decode(el, txt, p, lockSnd) {
    const n2 = txt.length, locked = Math.floor(clamp(p) * n2);
    let o = "";
    for (let i = 0; i < n2; i++) o += i < locked || txt[i] === " " ? txt[i] : CH[Math.random() * CH.length | 0];
    el.textContent = o;
    if (lockSnd && locked > (el._l || 0)) {
      el._l = locked;
      S_.lock();
    }
  }
  function bootFrame(t) {
    if (!booting) return;
    if (bootT0 === null) bootT0 = t;
    const s = (t - bootT0) / 1e3;
    const cv = $("bootCv");
    const { g, w, h } = cvFit(cv);
    const cx = w / 2, cy = h * 0.47;
    const hb = Math.pow(Math.max(0, Math.sin(s * Math.PI * 1.25)), 12);
    g.fillStyle = s < TL.warp ? "rgba(3,3,3,.5)" : "rgba(3,3,3,.42)";
    g.fillRect(0, 0, w, h);
    if (s < TL.flash) {
      const v = g.createRadialGradient(cx, cy, 0, cx, cy, Math.max(w, h) * 0.7);
      v.addColorStop(0, `rgba(255,255,255,${(0.06 + 0.22 * hb).toFixed(3)})`);
      v.addColorStop(1, "rgba(0,0,0,0)");
      g.fillStyle = v;
      g.fillRect(0, 0, w, h);
      if (s < TL.warp && hb > 0.9) once("hb" + Math.floor(s * 1.25), S_.beat);
    }
    if (s < TL.flash) {
      g.font = "12px 'Share Tech Mono',monospace";
      g.textAlign = "left";
      const per = 0.2, shown = s / per;
      d.log().forEach((L, i) => {
        if (shown < i) return;
        const part = L.slice(0, Math.floor(clamp(shown - i) * L.length));
        g.fillStyle = "rgba(255,255,255,.85)";
        g.fillText("> " + part, 24, 30 + i * 18);
        if (part.length < L.length) once("t" + i + "_" + (part.length >> 2), S_.tick);
      });
    }
    if (s >= TL.warp && s < TL.flash + 0.3) {
      once("riser", S_.riser);
      if (!WARP) {
        WARP = [];
        for (let i = 0; i < 2400; i++) WARP.push({ x: (Math.random() - 0.5) * 2, y: (Math.random() - 0.5) * 2, z: Math.random(), sp: 0.6 + Math.random() * 0.8, hot: Math.random() < 0.12 });
      }
      const k = clamp((s - TL.warp) / (TL.flash - TL.warp)), speed = 4e-3 + 0.06 * Math.pow(k, 2.2), shake = k > 0.6 ? (k - 0.6) * 14 : 0, sx = (Math.random() - 0.5) * shake, sy = (Math.random() - 0.5) * shake;
      g.globalCompositeOperation = "lighter";
      g.lineCap = "round";
      for (const off of [[-2.5, "200,200,200"], [2.5, "110,110,110"], [0, "255,255,255"]]) {
        g.strokeStyle = `rgba(${off[1]},${off[0] ? 0.35 : 0.75})`;
        g.lineWidth = off[0] ? 1 : 1.3;
        g.beginPath();
        for (const p of WARP) {
          if (!off[0]) {
            p.z -= speed * p.sp;
            if (p.z <= 0.01) {
              p.z = 1;
              p.x = (Math.random() - 0.5) * 2;
              p.y = (Math.random() - 0.5) * 2;
            }
          }
          const f = 0.35 / p.z, f2 = 0.35 / (p.z + speed * p.sp * (4 + k * 10)), x = cx + p.x * f * w * 0.5 + sx, y = cy + p.y * f * h * 0.5 + sy, x0 = cx + p.x * f2 * w * 0.5 + sx, y0 = cy + p.y * f2 * h * 0.5 + sy;
          if (x < -50 || x > w + 50 || y < -50 || y > h + 50) continue;
          g.moveTo(x0 + off[0] * k * (x - cx) / w * 10, y0);
          g.lineTo(x + off[0] * k * (x - cx) / w * 10, y);
        }
        g.stroke();
      }
      g.globalCompositeOperation = "source-over";
      for (let r = 0; r < 6; r++) {
        const z = (r / 6 - s * 1.4 * k) % 1, zz = z < 0 ? z + 1 : z, R = 40 / (zz + 0.05);
        g.strokeStyle = `rgba(255,255,255,${(0.25 * (1 - zz)).toFixed(3)})`;
        g.lineWidth = 1;
        g.beginPath();
        g.arc(cx, cy, R, 0, 7);
        g.stroke();
      }
    }
    if (s >= TL.flash && s < TL.flash + 0.7) {
      once("boom", () => {
        S_.boom();
        S_.chord();
      });
      const f = 1 - (s - TL.flash) / 0.7;
      g.fillStyle = `rgba(255,255,255,${(f * f).toFixed(3)})`;
      g.fillRect(0, 0, w, h);
      for (let r = 0; r < 3; r++) {
        const b = clamp((s - TL.flash) / 0.7 * 1.3 - r * 0.12);
        g.strokeStyle = `rgba(255,255,255,${(1 - b) * 0.8})`;
        g.lineWidth = 5 * (1 - b) + 1;
        g.beginPath();
        g.arc(cx, cy, b * Math.hypot(w, h) * 0.55, 0, 7);
        g.stroke();
      }
    }
    const st = $("introStage"), fx = $("introFx");
    if (s >= TL.reveal && s < TL.fly) {
      const k = eout((s - TL.reveal) / 1.2);
      st.style.opacity = "1";
      const iv = $("introVid");
      if (iv.paused) iv.play().catch(() => void 0);
      st.style.clipPath = `inset(${((1 - k) * 100).toFixed(1)}% 0 0 0)`;
      st.style.transform = `translate(-50%,-50%) scale(${(1.15 - 0.15 * k).toFixed(3)})`;
      const F = cvFit(fx), G = F.g;
      G.clearRect(0, 0, F.w, F.h);
      const ly = (1 - k) * F.h;
      if (k < 1) {
        const gr = G.createLinearGradient(0, ly - 20, 0, ly + 6);
        gr.addColorStop(0, "rgba(255,255,255,0)");
        gr.addColorStop(1, "rgba(255,255,255,.95)");
        G.fillStyle = gr;
        G.fillRect(0, ly - 20, F.w, 26);
      }
      const rk = eout((s - TL.reveal - 0.3) / 1), R = Math.min(w, h) * 0.3;
      g.save();
      g.translate(cx, cy);
      g.globalAlpha = rk;
      g.strokeStyle = "rgba(255,255,255,.7)";
      g.lineWidth = 1.2;
      g.rotate(s * 0.5);
      for (let q = 0; q < 4; q++) {
        g.beginPath();
        g.arc(0, 0, R, q * Math.PI / 2 + 0.2, q * Math.PI / 2 + 1.15);
        g.stroke();
      }
      g.rotate(-s * 1.2);
      g.setLineDash([3, 9]);
      g.beginPath();
      g.arc(0, 0, R * 0.9, 0, 7);
      g.stroke();
      g.setLineDash([]);
      g.rotate(s * 0.9);
      for (let q = 0; q < 60; q++) {
        const a = q / 60 * 6.283, L = q % 5 ? 4 : 10;
        g.beginPath();
        g.moveTo(Math.cos(a) * R * 1.08, Math.sin(a) * R * 1.08);
        g.lineTo(Math.cos(a) * (R * 1.08 + L), Math.sin(a) * (R * 1.08 + L));
        g.stroke();
      }
      g.restore();
      const fk = eout((s - TL.reveal - 0.6) / 0.8), rb = st.getBoundingClientRect(), bb = boot().getBoundingClientRect(), ks = scaleOf(boot());
      g.save();
      g.strokeStyle = `rgba(255,255,255,${fk})`;
      g.shadowColor = "#ffffff";
      g.shadowBlur = 20;
      g.lineWidth = 2;
      g.beginPath();
      g.ellipse(cx, (rb.bottom - bb.top - rb.height * 0.03) / ks, rb.width / ks * 0.42 * fk, 10 * fk, 0, 0, 7);
      g.stroke();
      g.restore();
      once("reveal", S_.whoosh);
    }
    const cur = d.cur();
    if (s >= TL.title && s < TL.fly + 0.4) {
      decode($("iT1"), "LEDGR", (s - TL.title) / 0.9, true);
      decode($("iT2"), cur.code + " \xB7 " + cur.name + " \xB7 COMMAND CENTER", (s - TL.title - 0.4) / 1.2);
    }
    if (s >= TL.stats && s < TL.fly + 0.4) {
      const sd = d.stats(), L = $("introL"), Rr = $("introR"), p = (s - TL.stats) / 1.4;
      const rows = sd ? [["NET P&L", sd.net], ["WIN RATE", sd.win], ["PROFIT FACTOR", sd.pf]] : [["LINK", "LEDGR"], ["FEED", "CME GLOBEX"], ["CONTRACT", cur.code + " \xB7 " + cur.name]];
      const rows2 = sd ? [["TRADES", sd.n], ["AVG R", sd.r], ["MAX DRAWDOWN", sd.dd]] : [["TICK", cur.tick + " = " + money(cur.tick * cur.pv)], ["POINT", money(cur.pv).replace(".00", "")], ["SESSION", d.session()]];
      const f = (rs, el) => {
        el.innerHTML = rs.map(([k, v], i) => {
          const q = clamp(p * 1.5 - i * 0.25);
          if (q <= 0) return "";
          let o = "";
          for (let j = 0; j < v.length; j++) o += j < Math.floor(q * v.length) ? v[j] : CH[Math.random() * CH.length | 0];
          return `${esc(k)}<b>${esc(o)}</b>`;
        }).join("");
      };
      f(rows, L);
      f(rows2, Rr);
      L.style.opacity = Rr.style.opacity = "1";
      once("st", S_.lock);
    }
    const m = $("introMsg");
    if (s >= TL.msg && s < TL.fly + 0.4) {
      const k = s - TL.msg;
      m.style.opacity = String(k < 0.15 ? Math.random() : 1);
      m.textContent = k < 0.6 ? "OPERATOR RECOGNISED" : "WELCOME BACK, " + d.name();
      if (k < 0.15) once("g1", S_.glitch);
      if (k > 0.6 && k < 0.75) once("g2", S_.glitch);
    }
    if (s > TL.reveal && Math.random() < 0.04) {
      const dpr = cv.width / w;
      for (let q = 0; q < 5; q++) {
        const y = Math.random() * h, hh = 3 + Math.random() * 16;
        g.drawImage(cv, 0, y * dpr, w * dpr, hh * dpr, (Math.random() - 0.5) * 40, y, w, hh);
      }
    }
    g.fillStyle = "rgba(255,255,255,.1)";
    g.fillRect(0, t * 0.4 % h, w, 2);
    if (s >= TL.fly) once("fly", () => {
      S_.whoosh();
      flyOut();
    });
    if (s >= TL.end) {
      endBoot();
      return;
    }
    life.frame(bootFrame);
  }
  function flyOut() {
    d.onFly();
    const st = $("introStage"), fig = d.root.querySelector(".figwrap"), b = boot();
    d.powerOn();
    ["introTitle", "introL", "introR", "introMsg"].forEach((id) => {
      $(id).style.transition = "opacity .35s";
      $(id).style.opacity = "0";
    });
    b.style.transition = "background-color .8s";
    b.style.backgroundColor = "rgba(3,3,3,0)";
    $("bootCv").style.transition = "opacity .5s";
    $("bootCv").style.opacity = "0";
    if (fig) {
      const a = st.getBoundingClientRect(), z = fig.getBoundingClientRect(), bb = b.getBoundingClientRect(), k = scaleOf(b), sc = Math.max(z.width / a.width, z.height / a.height);
      st.style.transition = "transform .9s cubic-bezier(.7,0,.2,1), left .9s cubic-bezier(.7,0,.2,1), top .9s cubic-bezier(.7,0,.2,1)";
      st.style.clipPath = "none";
      st.style.left = (z.left - bb.left + z.width / 2) / k + "px";
      st.style.top = (z.top - bb.top + z.height / 2) / k + "px";
      st.style.transform = `translate(-50%,-50%) scale(${sc.toFixed(3)})`;
    }
  }
  function resetIntro() {
    fired = {};
    WARP = null;
    bootT0 = null;
    ["introTitle", "introL", "introR", "introMsg"].forEach((id) => {
      $(id).style.transition = "";
      $(id).style.opacity = "";
    });
    $("introMsg").style.opacity = "0";
    $("introL").empty();
    $("introR").empty();
    $("iT1").textContent = "";
    $("iT2").textContent = "";
    const st = $("introStage");
    st.style.transition = "";
    st.style.left = "";
    st.style.top = "";
    st.style.opacity = "0";
    st.style.transform = "translate(-50%,-50%)";
    $("bootCv").style.transition = "";
    $("bootCv").style.opacity = "1";
    boot().style.transition = "";
    boot().style.backgroundColor = "";
  }
  function start(withSound) {
    gate().style.display = "none";
    $("skipBtn").style.display = "block";
    sound.on = withSound && sound.pref;
    if (sound.on) {
      sound.audio();
      if (sound.AC?.state === "suspended") void sound.AC.resume();
      S_.drone();
    }
    d.onStart();
    booting = true;
    resetIntro();
    life.frame(bootFrame);
  }
  function endBoot() {
    const b = boot();
    if (!booting && b.style.display === "none") return;
    const flew = !!fired.fly;
    booting = false;
    b.style.transition = "opacity .45s";
    b.style.opacity = "0";
    life.after(460, () => {
      b.style.display = "none";
      b.style.opacity = "1";
      resetIntro();
    });
    if (!flew) d.powerOn();
    d.onEnd();
  }
  function showGate() {
    boot().style.display = "block";
    gate().style.display = "flex";
    $("skipBtn").style.display = "none";
    resetIntro();
    const { g, w, h } = cvFit($("bootCv"));
    g.fillStyle = "#030303";
    g.fillRect(0, 0, w, h);
    life.after(8e3, () => {
      if (gate().style.display !== "none" && boot().style.display !== "none") start(false);
    });
    life.frame(gateBg);
  }
  function skip() {
    booting = true;
    gate().style.display = "none";
    endBoot();
  }
  function gateBg(t) {
    if (gate().style.display === "none" || boot().style.display === "none") return;
    const { g, w, h } = cvFit($("bootCv"));
    g.fillStyle = "rgba(3,3,3,.25)";
    g.fillRect(0, 0, w, h);
    const hb = Math.pow(Math.max(0, Math.sin(t / 1e3 * Math.PI * 0.8)), 10), v = g.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, Math.max(w, h) * 0.6);
    v.addColorStop(0, `rgba(255,255,255,${(0.04 + 0.14 * hb).toFixed(3)})`);
    v.addColorStop(1, "rgba(0,0,0,0)");
    g.fillStyle = v;
    g.fillRect(0, 0, w, h);
    g.fillStyle = "rgba(255,255,255,.08)";
    g.fillRect(0, t * 0.15 % h, w, 1);
    life.frame(gateBg);
  }
  d.root.querySelector(".gring").onclick = () => start(true);
  $("gskip").onclick = () => {
    gate().style.display = "none";
    booting = true;
    endBoot();
  };
  $("skipBtn").onclick = () => endBoot();
  life.on(d.root, "keydown", (e) => {
    if (boot().style.display === "none") return;
    if (gate().style.display !== "none" && e.key === "Enter") start(true);
    else if (e.key === "Escape") endBoot();
  });
  return { showGate, skip, isRunning: () => boot().style.display !== "none" };
}

// src/cc/canvas/radar.ts
function createRadar(cv, zone2) {
  return function draw(t) {
    const Z = zone2();
    const { g, w, h } = fit(cv);
    g.clearRect(0, 0, w, h);
    const cx = w / 2, cy = h / 2 - 8, R = Math.min(w, h) * 0.38;
    const now = Z.local(/* @__PURE__ */ new Date()), hr = now.getUTCHours() + now.getUTCMinutes() / 60, A = (x) => x / 24 * 2 * Math.PI - Math.PI / 2;
    const oH = Z.tzOff(/* @__PURE__ */ new Date()) / 36e5, inA = (x, a2, b) => ((x - a2) % 24 + 24) % 24 < b - a2;
    [[-1 + oH, 7 + oH, "ASIA"], [7 + oH, 13.5 + oH, "LONDON"], [13.5 + oH, 21 + oH, "NEW YORK"]].forEach(([a2, b], i) => {
      g.strokeStyle = inA(hr, a2, b) ? "rgba(255,255,255,.95)" : "rgba(122,122,122,.9)";
      g.lineWidth = 9;
      g.beginPath();
      g.arc(cx, cy, R - i * 14, A(a2), A(b));
      g.stroke();
    });
    g.lineWidth = 1;
    g.strokeStyle = "rgba(122,122,122,.8)";
    for (let k = 0; k < 24; k++) {
      const a2 = A(k);
      g.beginPath();
      g.moveTo(cx + Math.cos(a2) * (R + 4), cy + Math.sin(a2) * (R + 4));
      g.lineTo(cx + Math.cos(a2) * (R + (k % 6 ? 8 : 13)), cy + Math.sin(a2) * (R + (k % 6 ? 8 : 13)));
      g.stroke();
    }
    const sw = t * 12e-4 % (2 * Math.PI), gr = g.createConicGradient ? g.createConicGradient(sw - 0.8, cx, cy) : null;
    if (gr) {
      gr.addColorStop(0, "rgba(255,255,255,0)");
      gr.addColorStop(0.12, "rgba(255,255,255,.25)");
      gr.addColorStop(0.13, "rgba(255,255,255,0)");
      g.fillStyle = gr;
      g.beginPath();
      g.arc(cx, cy, R - 36, 0, 7);
      g.fill();
    }
    const a = A(hr);
    g.strokeStyle = "#ffffff";
    g.lineWidth = 1.5;
    g.beginPath();
    g.moveTo(cx, cy);
    g.lineTo(cx + Math.cos(a) * (R + 10), cy + Math.sin(a) * (R + 10));
    g.stroke();
    g.fillStyle = "#ffffff";
    g.font = "16px 'Share Tech Mono',monospace";
    g.textAlign = "center";
    g.fillText(now.toISOString().slice(11, 16), cx, cy + 5);
    g.font = "9px 'Share Tech Mono',monospace";
    g.fillStyle = "#c2c2c2";
    g.fillText(cityOf(Z.tz), cx, cy + 18);
    g.font = "9.5px 'Share Tech Mono',monospace";
    g.fillStyle = "#c2c2c2";
    g.fillText("ASIA \xB7 LONDON \xB7 NEW YORK (OUT\u2192IN)", cx, h - 4);
  };
}

// src/cc/life.ts
var Life = class {
  /** The window the command center lives in (its own window when opened as a popout). */
  constructor(win = window) {
    this.win = win;
    this.offs = [];
    this.alive = true;
    this.timeouts = /* @__PURE__ */ new Set();
    this.frames = /* @__PURE__ */ new Set();
  }
  on(t, type, fn, opts) {
    const h = fn;
    t.addEventListener(type, h, opts);
    this.offs.push(() => t.removeEventListener(type, h, opts));
  }
  every(ms, fn) {
    const id = this.win.setInterval(fn, ms);
    this.offs.push(() => this.win.clearInterval(id));
    return id;
  }
  after(ms, fn) {
    const id = this.win.setTimeout(() => {
      this.timeouts.delete(id);
      if (this.alive) fn();
    }, ms);
    this.timeouts.add(id);
    return id;
  }
  clear(id) {
    this.win.clearTimeout(id);
    this.timeouts.delete(id);
  }
  /** requestAnimationFrame that stops once the view is closed. */
  frame(fn) {
    const id = this.win.requestAnimationFrame((t) => {
      this.frames.delete(id);
      if (this.alive) fn(t);
    });
    this.frames.add(id);
  }
  /** Timeouts made with after() are tracked until they fire or the view closes. */
  dispose() {
    this.alive = false;
    this.frames.forEach((id) => this.win.cancelAnimationFrame(id));
    this.frames.clear();
    this.timeouts.forEach((id) => this.win.clearTimeout(id));
    this.timeouts.clear();
    this.offs.splice(0).forEach((f) => f());
  }
};

// src/cc/sound.ts
var Sound = class {
  constructor() {
    this.AC = null;
    this.on = false;
    // sound is playing (unlocked by a user gesture and allowed)
    this.pref = true;
    /** The intro's sound effects. */
    this.fx = {
      drone: () => {
        this.tone(55, 3.6, "sawtooth", 0.05, 40);
        this.tone(82.5, 3.6, "sine", 0.08, 60);
      },
      beat: () => {
        this.tone(60, 0.35, "sine", 0.35, 38);
        this.tone(52, 0.35, "sine", 0.25, 34, 0.18);
      },
      tick: () => {
        this.tone(1800 + Math.random() * 600, 0.04, "square", 0.03);
      },
      riser: () => {
        this.noise(2.2, 0.22, 300, 9e3);
        this.tone(110, 2.2, "sawtooth", 0.05, 880);
      },
      boom: () => {
        this.tone(70, 1.8, "sine", 0.6, 28);
        this.noise(1.2, 0.35, 4e3, 120);
        this.tone(140, 0.5, "square", 0.08, 40);
      },
      lock: () => {
        this.tone(880, 0.08, "square", 0.06);
        this.tone(1320, 0.12, "square", 0.05, void 0, 0.07);
      },
      glitch: () => {
        this.noise(0.18, 0.18, 2e3, 2600);
        this.tone(200 + Math.random() * 900, 0.12, "square", 0.05);
      },
      whoosh: () => {
        this.noise(0.7, 0.25, 6e3, 300);
      },
      chord: () => {
        [220, 277, 330, 440].forEach((f, i) => this.tone(f, 2.4, "triangle", 0.05, void 0, i * 0.04));
      }
    };
  }
  // the user wants sound
  audio() {
    if (this.AC) return this.AC;
    try {
      this.AC = new (window.AudioContext || window.webkitAudioContext)();
    } catch {
      this.AC = null;
    }
    return this.AC;
  }
  /** Called on a user gesture: browsers only allow audio after one. */
  unlock() {
    if (this.pref && !this.on) {
      this.audio();
      if (this.AC) {
        void this.AC.resume();
        this.on = true;
      }
    }
  }
  tone(f, d, type = "sine", vol = 0.15, glideTo, delay = 0) {
    const AC = this.AC;
    if (!this.on || !AC) return;
    const t = AC.currentTime + delay, o = AC.createOscillator(), g = AC.createGain();
    o.type = type;
    o.frequency.setValueAtTime(f, t);
    if (glideTo) o.frequency.exponentialRampToValueAtTime(glideTo, t + d);
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(vol, t + 0.01);
    g.gain.exponentialRampToValueAtTime(1e-4, t + d);
    o.connect(g).connect(AC.destination);
    o.start(t);
    o.stop(t + d + 0.05);
  }
  noise(d, vol = 0.2, from = 800, to = 8e3, delay = 0) {
    const AC = this.AC;
    if (!this.on || !AC) return;
    const t = AC.currentTime + delay, n2 = AC.sampleRate * d, b = AC.createBuffer(1, n2, AC.sampleRate), c = b.getChannelData(0);
    for (let i = 0; i < n2; i++) c[i] = Math.random() * 2 - 1;
    const src = AC.createBufferSource();
    src.buffer = b;
    const f = AC.createBiquadFilter();
    f.type = "bandpass";
    f.Q.value = 1.2;
    f.frequency.setValueAtTime(from, t);
    f.frequency.exponentialRampToValueAtTime(to, t + d);
    const g = AC.createGain();
    g.gain.setValueAtTime(1e-4, t);
    g.gain.exponentialRampToValueAtTime(vol, t + d * 0.85);
    g.gain.exponentialRampToValueAtTime(1e-4, t + d);
    src.connect(f).connect(g).connect(AC.destination);
    src.start(t);
  }
  blip() {
    this.tone(1400, 0.05, "square", 0.025);
  }
  alarm(n2 = 3) {
    for (let i = 0; i < n2; i++) {
      this.tone(880, 0.14, "square", 0.07, void 0, i * 0.22);
      this.tone(660, 0.14, "square", 0.05, void 0, i * 0.22 + 0.1);
    }
  }
  close() {
    void this.AC?.close().catch(() => void 0);
    this.AC = null;
    this.on = false;
  }
};

// src/cc/template.ts
var TEMPLATE = `<div id="boot"><canvas id="bootCv"></canvas>
  <div id="introStage"><video id="introVid" muted playsinline loop preload="auto"></video><canvas id="introFx"></canvas></div>
  <div id="introTitle"><div id="iT1"></div><div id="iT2"></div></div>
  <div id="introL" class="istat"></div><div id="introR" class="istat"></div>
  <div id="introMsg"></div>
  <div id="gate"><div class="gring"><div class="gbtn" id="engage">ENGAGE</div></div><div class="ghint">CLICK OR PRESS ENTER \xB7 SOUND ON</div><div class="gskip" id="gskip">SKIP INTRO \u203A</div></div>
  <div id="skipBtn">SKIP \u203A</div>
  <div id="bootTxt"><small id="bootSub"></small></div></div>


<div class="app">
  <div class="top">
    <div class="brand">LEDGR</div>
    <div class="tabs" id="tabs" style="flex:none">
      <div class="tab on" data-v="main">MAIN</div><div class="tab" data-v="markets">MARKETS</div><div class="tab" data-v="journal">JOURNAL</div>
      <div class="tab" data-v="perf">PERFORMANCE</div><div class="tab" data-v="chart">CHART</div><div class="tab" data-v="risk">RISK</div><div class="tab" data-v="news">NEWS</div><div class="tab" data-v="brain">BRAIN</div>
    </div>
    <div id="ff"><a id="ffLogo" href="#">CAL</a><div id="ffTick"><span class="ffmut">ECONOMIC CALENDAR \xB7 LOADING\u2026</span></div><div id="ffBtn" title="This week's calendar">\u25BE</div></div>
    <div id="guardChip" class="gchip" title="Risk guard (RISK tab)">GUARD \xB7 \u2014</div><div id="sndBtn" class="sndb" title="Sound on/off">SND ON</div>
    <div class="stat"><span class="dot" id="linkDot"></span><span id="linkTxt">LINK OFFLINE</span></div>
  </div>
  <div id="tape" class="tvw"></div>

  <div class="main">
    <!-- LEFT -->
    <div class="col">
      <div class="panel"><div class="ph"><b data-tzl="@" style="font-weight:inherit">LOCAL</b> <span id="dateTxt"></span></div><div class="clock" id="clock">00:00:00</div>
        <div class="kv" style="margin-top:8px"><span class="k">NEW YORK</span><span class="v" id="nyT"></span><span class="k">LONDON</span><span class="v" id="ldT"></span><span class="k">TOKYO</span><span class="v" id="tkT"></span></div></div>
      <div class="panel"><div class="ph">ACCOUNT <select id="insSel" title="Instrument from your journal" style="background:#0b0b0b;color:inherit;border:1px solid rgba(122,122,122,.5);font:inherit;font-size:10px;letter-spacing:.08em;padding:1px 4px;max-width:150px;cursor:pointer"><option value="AUTO">AUTO</option></select></div>
        <div class="sub">NET P&amp;L \xB7 ALL TIME</div><div class="big" id="kNet">\u2014</div>
        <div class="kv" style="margin-top:8px"><span class="k">WIN RATE</span><span class="v" id="kWin">\u2014</span><span class="k">PROFIT FACTOR</span><span class="v" id="kPF">\u2014</span><span class="k">AVG R</span><span class="v" id="kR">\u2014</span><span class="k">MAX DRAWDOWN</span><span class="v" id="kDD">\u2014</span><span class="k">TRADES</span><span class="v" id="kN">\u2014</span></div></div>
      <div class="panel"><div class="ph">P&amp;L CURVE <span>30D</span></div><canvas id="spark" height="70"></canvas></div>
      <div class="panel"><div class="ph">ORDER FLOW <span>LONG / SHORT</span></div>
        <div class="kv"><span class="k">LONG</span><span class="v" id="lsL">\u2014</span><span class="k">SHORT</span><span class="v" id="lsS">\u2014</span></div>
        <div class="bar"><i id="lsBarL" style="background:var(--ok);width:50%"></i><i id="lsBarS" style="background:var(--r);width:50%"></i></div></div>
      <div class="panel"><div class="ph">TODAY <span id="todayDate"></span></div>
        <div class="kv"><span class="k">TRADES</span><span class="v" id="tdN">0</span><span class="k">NET</span><span class="v" id="tdNet">$0.00</span><span class="k">NET R</span><span class="v" id="tdR">\u2014</span></div></div>
    </div>

    <!-- CENTER -->
    <div class="center">
      <div class="view on" id="v-main"><div class="hud-grid" style="grid-template-columns:minmax(260px,30%) minmax(0,1fr)">
        <div class="panel figure"><div class="ph">OPERATOR <span>SCAN</span></div><div class="figwrap"><video id="figVid" autoplay muted loop playsinline preload="auto" ></video><canvas id="figCv"></canvas></div><div class="fname">OPERATOR</div><div class="sub" id="opSub" style="text-align:center;letter-spacing:.2em">TRADER</div></div>
        <div class="mainR"><div class="panel" style="flex:1.35;min-height:0"><div class="ph">NEURAL MAP <span>DRAG TO ROTATE \xB7 HOVER A NODE</span></div><canvas id="brainCv"></canvas>
          <div class="chips" id="brainChips"></div></div>
        <div class="panel" style="flex:1;min-height:0;padding:8px 10px 6px"><div class="ph" id="liveHd">LIVE <span>5M \xB7 <a class="tvattr" href="https://www.tradingview.com/" target="_blank" rel="noopener">TRADINGVIEW</a></span></div><div id="liveChart" class="tvw" style="height:calc(100% - 22px)"><div class="note">Connecting to live market\u2026</div></div></div></div>
      </div></div>
      <div class="view" id="v-markets"><div class="panel" style="height:100%"><div class="ph">GLOBAL MARKET UPLINK <span id="mkLocal"></span></div><canvas id="globeCv"></canvas>
        <div class="chips"><span class="chip on">TOKYO</span><span class="chip on">LONDON</span><span class="chip on">NEW YORK</span><span class="chip on">CHICAGO \xB7 CME</span><span class="chip on" data-tzl="@">LOCAL</span></div></div></div>
      <div class="view" id="v-journal"><div class="hud-grid" style="grid-template-columns:minmax(0,1.2fr) minmax(0,1fr)">
        <div class="panel" style="height:100%"><div class="ph">TRADE LOG <span id="logCount"></span></div><div class="scroll"><table id="logT"></table></div></div>
        <div class="panel" style="height:100%"><div class="ph">CALENDAR <span><a id="calPrev" style="cursor:pointer">\u25C0</a> <span id="calTitle"></span> <a id="calNext" style="cursor:pointer">\u25B6</a></span></div><div class="cal" id="cal"></div></div>
      </div></div>
      <div class="view" id="v-perf"><div class="hud-grid" style="grid-template-columns:minmax(0,1fr) minmax(0,1fr);grid-template-rows:1fr 1fr">
        <div class="panel" style="grid-column:span 2"><div class="ph">EQUITY <span>CLOSED TRADES</span></div><canvas id="eqCv"></canvas></div>
        <div class="panel"><div class="ph">BY SESSION <span data-tzl="@ TIME">LOCAL TIME</span></div><canvas id="sessCv"></canvas></div>
        <div class="panel"><div class="ph">BY SETUP <span>NET</span></div><canvas id="setupCv"></canvas></div>
      </div></div>
      <div class="view" id="v-chart"><div class="panel" style="height:100%;padding:6px"><div class="ph" id="chartHd" style="margin:2px 6px 6px">CHART <span><a class="tvattr" href="https://www.tradingview.com/" target="_blank" rel="noopener">TRADINGVIEW</a></span></div><div id="tvbox" style="height:calc(100% - 28px)"><div class="note" style="padding:20px">Loading chart\u2026</div></div></div></div>
      <div class="view" id="v-risk"><div class="hud-grid" style="grid-template-columns:repeat(3,minmax(0,1fr))">
        <div class="panel" style="height:100%"><div class="ph">PRE-TRADE CHECKLIST <span id="ckState"></span></div><div class="scroll" id="ckList"></div></div>
        <div class="panel" style="height:100%"><div class="ph">RISK GUARD <span data-tzl="TODAY \xB7 @">TODAY</span></div><div class="scroll">
          <div class="gbig" id="gBig">\u2014</div><div class="sub" id="gWhy" style="text-align:center;margin-bottom:10px"></div>
          <div id="gBars"></div>
          <div class="sec2">LIMITS</div>
          <div class="frm"><label>Daily loss limit ($)<input class="inp" id="gLoss" type="number" min="0" step="10"></label><label>Max trades / day<input class="inp" id="gTrades" type="number" min="1" step="1"></label>
          <label>Max losses in a row<input class="inp" id="gConsec" type="number" min="1" step="1"></label><label>Cool-down after a loss (min)<input class="inp" id="gCool" type="number" min="0" step="1"></label></div></div></div>
        <div class="panel" style="height:100%"><div class="ph" id="posHd">POSITION SIZE</div><div class="scroll">
          <div class="frm"><label>Account ($)<input class="inp" id="pAcc" type="number" step="100"></label><label>Risk per trade (%)<input class="inp" id="pPct" type="number" step="0.1"></label>
          <label>Entry<input class="inp" id="pEn" type="number" step="0.1" placeholder="e.g. 2650.0"></label><label>Stop<input class="inp" id="pSt" type="number" step="0.1" placeholder="e.g. 2646.5"></label>
          <label>Fees / contract round trip ($)<input class="inp" id="pFee" type="number" step="0.01"></label><label>Max contracts<input class="inp" id="pMax" type="number" step="1"></label></div>
          <div id="pOut"></div></div></div>
      </div></div>
      <div class="view" id="v-news"><div class="hud-grid" style="grid-template-columns:minmax(0,1.3fr) minmax(0,1fr)">
        <div class="panel" style="height:100%;padding:8px 10px"><div class="ph" id="newsHd">NEWS FEED <span><a class="tvattr" href="https://www.tradingview.com/" target="_blank" rel="noopener">TRADINGVIEW</a> \xB7 LIVE</span></div><div id="newsFeed" class="tvw" style="height:calc(100% - 22px)"><div class="note">Loading headlines\u2026</div></div></div>
        <div style="display:grid;grid-template-rows:minmax(0,1.1fr) minmax(0,1fr);gap:8px;min-height:0">
          <div class="panel" style="padding:8px 10px"><div class="ph" id="sentHd">SENTIMENT <span>TECHNICAL RATING</span></div><div id="sentiment" class="tvw" style="height:calc(100% - 22px)"></div></div>
          <div class="panel"><div class="ph">HIGH-IMPACT AHEAD <span>ECONOMIC CALENDAR</span></div><div class="scroll" id="hiList"></div></div>
        </div></div></div>
      <div class="view" id="v-brain"><div class="panel" style="height:100%"><div class="ph">PSYCHE REPORT <span>FROM YOUR JOURNAL</span></div><div class="scroll" id="psyche"></div></div></div>
    </div>

    <!-- RIGHT -->
    <div class="col right">
      <div class="panel" style="padding:8px 10px 2px"><div class="ph" id="quoteHd">LIVE</div><div id="goldQuote" class="tvw" style="height:92px"><div class="note">Connecting\u2026</div></div></div>
      <div class="panel"><div class="ph">RISK GUARD <span id="rgSub">TODAY</span></div><div class="gmini" id="gMini">\u2014</div><div id="gMiniBars"></div></div>
      <div class="panel"><div class="ph">MARKET STATUS <span>CME GLOBEX</span></div>
        <div class="big" id="cmeState">\u2014</div><div class="sub" id="cmeNext"></div>
        <div class="kv" id="specK" style="margin-top:8px"></div></div>
      <div class="panel"><div class="ph">SESSION RADAR <span id="sessNow"></span></div><canvas id="radarCv" height="210"></canvas></div>
      <div class="panel"><div class="ph">ACTIVITY FEED <span>LATEST</span></div><div class="feed" id="feed"><div class="note">No trades yet.</div></div></div>
      <div class="panel"><div class="ph">LEDGR SYNC <span id="syncT"></span></div><div class="big" id="syncState" style="font-size:18px">OFFLINE</div><div class="sub" id="syncSub">Connect a key to load your journal.</div></div>
    </div>
  </div>

  <div class="dock">
    <a class="ic" href="https://www.ledgrjournal.app/dashboard" target="_blank" rel="noopener"><b>\u25C8</b>LEDGR</a>
    <a class="ic" href="https://www.ledgrjournal.app/journal" target="_blank" rel="noopener"><b>\u2630</b>JOURNAL</a>
    <a class="ic" href="https://www.ledgrjournal.app/dashboard" target="_blank" rel="noopener"><b>\u25A6</b>DASHBOARD</a>
    <a class="ic" href="#" data-action="vault"><b>\u25C9</b>VAULT</a>
    <div class="ic" id="refreshBtn"><b>\u21BB</b>SYNC</div>
    <div class="ic" id="replayBtn"><b>\u25B6</b>BOOT</div>
    <div class="ic" id="keyBtn"><b>\u26BF</b>KEY</div>
  </div>
</div>
<div id="ffPanel" class="panel"><div class="ph">ECONOMIC CALENDAR \xB7 THIS WEEK <span id="ffUpd"></span></div>
  <div class="fffil"><span class="chip on" data-c="USD">USD</span><span class="chip" data-c="ALL">ALL</span><span style="width:12px"></span><span class="chip on" data-i="2">HIGH + MED</span><span class="chip" data-i="3">HIGH</span><span class="chip" data-i="1">ALL IMPACT</span><a class="chip" id="calSrc" target="_blank" rel="noopener" style="margin-left:auto;display:none"></a></div>
  <div class="scroll" id="ffList"></div></div>
<div id="toasts"></div>
<div id="tip"></div>`;

// src/cc/tradingview.ts
var TV_SANDBOX = "allow-scripts allow-same-origin allow-popups allow-popups-to-escape-sandbox";
var TV_ATTRIBUTION = "https://www.tradingview.com/";
var EMBED = "https://www.tradingview-widget.com/embed-widget/";
var SIZE = {
  "ticker-tape": { width: "100%", height: 84 },
  "single-quote": { width: "100%", height: 101 },
  "advanced-chart": { width: "100%", height: "100%" },
  timeline: { width: "100%", height: "100%" },
  "technical-analysis": { width: "100%", height: "100%" }
};
var FRAME_HEIGHT = { "ticker-tape": "86px", "single-quote": "69px" };
function embedUrl(name, cfg) {
  const { locale, ...rest } = cfg;
  const full = { ...rest };
  if (name === "timeline") delete full.feedMode;
  const size2 = SIZE[name] ?? { width: "100%", height: "100%" };
  if (full.width === void 0) full.width = size2.width;
  if (full.height === void 0) full.height = size2.height;
  Object.assign(full, { utm_source: "", utm_medium: "widget", utm_campaign: name, "page-uri": "__NHTTP__" });
  if (full.autosize) {
    full.width = "100%";
    full.height = "100%";
  }
  const query = name === "timeline" ? `?symbol=${encodeURIComponent(String(cfg.symbol ?? ""))}` : `?locale=${locale ?? "en"}`;
  return EMBED + name + "/" + query + "#" + encodeURIComponent(JSON.stringify(full));
}
function chartUrl(o) {
  const hash = {
    symbol: o.symbol,
    frameElementId: o.frameId,
    interval: o.interval,
    hide_side_toolbar: o.hide_side_toolbar ? "1" : "0",
    allow_symbol_change: o.allow_symbol_change ? "1" : "0",
    save_image: "1",
    backgroundColor: o.backgroundColor,
    gridColor: o.gridColor,
    studies: "[]",
    theme: o.theme,
    style: o.style,
    timezone: o.timezone,
    withdateranges: o.withdateranges ? "1" : "0",
    studies_overrides: "{}",
    utm_medium: "widget",
    utm_campaign: "chart",
    utm_term: o.symbol,
    "page-uri": "__NHTTP__"
  };
  const q = `hideideas=1&overrides=${encodeURIComponent(JSON.stringify(o.overrides))}&enabled_features=${encodeURIComponent("[]")}&disabled_features=${encodeURIComponent("[]")}&locale=${o.locale}`;
  return `https://s.tradingview.com/widgetembed/?${q}#${encodeURIComponent(JSON.stringify(hash))}`;
}
function mountWidget(el, name, cfg) {
  el.empty();
  const wrap = el.createDiv({ cls: "tradingview-widget-container" });
  const h = FRAME_HEIGHT[name];
  wrap.setCssStyles({ width: "100%", height: h ?? "100%" });
  const f = frame(wrap, embedUrl(name, cfg), `${name.replace(/-/g, " ")} TradingView widget`);
  f.setCssStyles({ height: h ?? "100%" });
  return f;
}
function mountChart(el, url, frameId) {
  el.empty();
  const wrap = el.createDiv();
  wrap.setCssStyles({ position: "relative", boxSizing: "content-box", width: "100%", height: "100%", margin: "0 auto", padding: "0" });
  const f = frame(wrap, url, "advanced chart TradingView widget");
  f.id = frameId;
  f.setAttribute("allowfullscreen", "true");
  return f;
}
function frame(parent, src, title) {
  const f = parent.createEl("iframe");
  f.setAttribute("sandbox", TV_SANDBOX);
  f.setAttribute("referrerpolicy", "no-referrer");
  f.setAttribute("scrolling", "no");
  f.setAttribute("allowtransparency", "true");
  f.setAttribute("frameborder", "0");
  f.setAttribute("loading", "lazy");
  f.title = title;
  f.lang = "en";
  f.setCssStyles({ userSelect: "none", boxSizing: "border-box", display: "block", width: "100%", height: "100%", border: "0" });
  f.src = src;
  return f;
}

// src/cc/app.ts
var DESIGN_H = 900;
var DESIGN_W = 1400;
var CK_DEF = ["Higher-timeframe bias marked", "Key levels drawn", "Setup is in my playbook", "Stop and target set before entry", "Size from the calculator, not a guess", "Calm, not chasing or revenge trading"];
var TV_LINK = `<a class="tvattr" href="${TV_ATTRIBUTION}" target="_blank" rel="noopener">TRADINGVIEW</a>`;
var CommandCenter = class {
  constructor(root, host) {
    this.root = root;
    this.host = host;
    this.sound = new Sound();
    this.$ = (id) => this.root.querySelector("#" + id);
    this.NAME = "TRADER";
    this.ALLTR = [];
    this.TR = [];
    this.INSLIST = [];
    this.CUR = prof("MGC");
    this.calM = null;
    this.LOG = ["LEDGR KERNEL 1.0 ............ OK", "MOUNT /journal ............... OK", "CME GLOBEX FEED .............. LINKED", "RISK ENGINE .................. ARMED", "NEURAL MAP ................... 7 NODES", "DECRYPTING OPERATOR .......... TRADER"];
    this.FF = null;
    this.cal = { kind: "missing" };
    this.FFC = "USD";
    this.FFI = 2;
    this.ffRunKey = "";
    this.ALERT_PREV = {};
    this.lastLevel = "";
    this.widgetsLoaded = false;
    this.newsLoaded = false;
    this.chartLoaded = false;
    this.loading = false;
    this.loadedEarly = false;
    this.disconnectObserver = null;
    this.ffPass = (e) => (this.FFC === "ALL" || e.country === this.FFC) && e.i >= this.FFI;
    this.hhmm = (d) => this.Z.local(d).toISOString().slice(11, 16);
    this.life = new Life(root.ownerDocument.defaultView ?? window);
    const s = host.settings();
    this.TZN = s.timezone && okTZ(s.timezone) ? s.timezone : Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC";
    this.Z = zone(this.TZN);
    this.INSSEL = host.store.get("cc_ins", s.symbol || "AUTO");
    this.RG = { ...GUARD_DEFAULT, ...host.store.get("cc_guard", {}) };
    this.PS = { ...SIZING_DEFAULT, ...host.store.get("cc_pos", {}) };
    this.CK = host.store.get("cc_ck_items", CK_DEF.slice());
    this.sound.pref = s.sound;
    this.setName(host.name());
  }
  // ================================================================== mount / unmount
  mount() {
    const { root, life } = this;
    root.empty();
    root.addClass("ledgr-cc");
    root.tabIndex = -1;
    this.stage = root.createDiv({ cls: "ledgr-cc-stage" });
    const doc = new DOMParser().parseFromString(`<div>${TEMPLATE}</div>`, "text/html");
    for (const n2 of Array.from(doc.body.firstElementChild.childNodes)) this.stage.appendChild(root.ownerDocument.adoptNode(n2));
    this.fitStage();
    ["figCv", "brainCv", "globeCv", "eqCv", "sessCv", "setupCv"].forEach((id) => this.$(id).dataset.flex = "1");
    const tipEl = this.$("tip");
    const tip = {
      show: (e, html) => {
        const r = this.stage.getBoundingClientRect(), k = r.width / (this.stage.offsetWidth || r.width);
        tipEl.innerHTML = html;
        tipEl.style.display = "block";
        tipEl.style.left = Math.min(this.stage.offsetWidth - 220, (e.clientX - r.left) / k + 12) + "px";
        tipEl.style.top = (e.clientY - r.top) / k + 12 + "px";
      },
      hide: () => {
        tipEl.style.display = "none";
      }
    };
    this.brain = createBrain(this.$("brainCv"), this.$("brainChips"), life, tip);
    this.drawGlobe = createGlobe(this.$("globeCv"), () => this.TZN);
    this.drawRadar = createRadar(this.$("radarCv"), () => this.Z);
    this.drawFig = createFigure(this.$("figCv"), this.$("figVid"), life);
    void this.host.videoUrl().then((url) => {
      if (!url || !life.alive) return;
      this.$("figVid").src = url;
      this.$("introVid").src = url;
    });
    this.wire();
    this.initRisk();
    this.intro = createIntro({
      $: this.$,
      root,
      life,
      sound: this.sound,
      log: () => this.LOG,
      name: () => this.NAME,
      cur: () => this.CUR,
      stats: () => this.introStats(),
      session: () => sessOf(/* @__PURE__ */ new Date()),
      powerOn: () => this.powerOn(),
      onStart: () => {
        if (!this.loadedEarly) {
          this.loadedEarly = true;
          void this.load(false);
        }
      },
      onFly: () => this.loadWidgets(),
      onEnd: () => {
        this.loadWidgets();
        if (!this.loadedEarly) {
          this.loadedEarly = true;
          void this.load(false);
        }
        this.renderData();
      }
    });
    const c = this.host.cached();
    if (c) {
      this.ALLTR = c.trades.map(norm);
      this.buildIns();
      this.setLink(false, "CACHED");
      this.syncPanel("STALE", "down", `${this.TR.length} trades \xB7 cached ${new Date(c.at).toLocaleString("en-GB")}`);
    } else this.buildIns();
    this.applyLabels();
    this.setSndBtn();
    this.renderData();
    this.tick();
    life.every(1e3, () => this.tick());
    void this.calLoad();
    life.every(10 * 6e4, () => void this.calLoad());
    life.every(1e3, () => {
      this.ffRender();
      this.checkAlerts();
    });
    life.every(5 * 6e4, () => void this.load(false));
    life.frame((t) => this.loop(t));
    if (this.host.settings().intro) this.intro.showGate();
    else this.intro.skip();
  }
  unmount() {
    this.disconnectObserver?.();
    this.life.dispose();
    this.sound.close();
    this.root.empty();
  }
  /** Settings changed in the plugin's settings tab. */
  applySettings() {
    const s = this.host.settings();
    const tz = s.timezone && okTZ(s.timezone) ? s.timezone : Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC";
    if (tz !== this.TZN) {
      this.TZN = tz;
      this.Z = zone(tz);
      this.calM = null;
      this.renderData();
    }
    this.sound.pref = s.sound;
    if (!s.sound) this.sound.on = false;
    this.setSndBtn();
    this.refreshMarket(true);
    this.applyLabels();
  }
  setName(n2) {
    const first = String(n2 ?? "").trim().split(/\s+/)[0];
    this.NAME = (first || "TRADER").toUpperCase();
    this.LOG[5] = this.padL("DECRYPTING OPERATOR", this.NAME);
  }
  // ================================================================== data
  async load(full) {
    if (this.loading) return;
    this.loading = true;
    this.setLink(null, "SYNCING\u2026");
    try {
      const r = await this.host.sync(full);
      if (!this.life.alive) return;
      this.setName(this.host.name());
      if (r.ok) {
        this.ALLTR = r.trades.map(norm);
        this.buildIns();
        this.setLink(true, "LINK ONLINE");
        this.syncPanel("ONLINE", "up", `${this.TR.length} trades \xB7 as of LEDGR's last sync`);
        this.$("syncT").textContent = new Date(r.at).toLocaleTimeString("en-GB");
      } else {
        if (r.trades) {
          this.ALLTR = r.trades.map(norm);
          this.buildIns();
        }
        const rejected = r.kind === "invalid_key" || r.kind === "not_pro";
        this.setLink(false, rejected ? "KEY REJECTED" : r.trades ? "LINK LOST \xB7 CACHED" : "LINK LOST");
        this.syncPanel(r.trades ? "STALE" : "OFFLINE", "down", r.trades && r.at ? `${r.message} Showing trades cached ${new Date(r.at).toLocaleString("en-GB")}.` : r.message);
      }
    } finally {
      this.loading = false;
    }
    this.renderData();
  }
  syncPanel(state, tone, sub) {
    this.$("syncState").textContent = state;
    this.$("syncState").className = "big " + tone;
    this.$("syncSub").textContent = sub;
  }
  buildIns() {
    const { list, cnt } = instrumentsOf(this.ALLTR);
    this.INSLIST = list;
    const sel = this.$("insSel");
    sel.empty();
    const opt = (v, t) => sel.createEl("option", { value: v, text: t });
    opt("AUTO", `AUTO \xB7 ${list[0] || "\u2014"}`);
    list.forEach((k) => opt(k, `${k} \xB7 ${cnt[k]}`));
    if (list.length > 1) opt("ALL", `ALL SYMBOLS \xB7 ${this.ALLTR.length}`);
    if (this.INSSEL !== "AUTO" && this.INSSEL !== "ALL" && !list.includes(this.INSSEL)) this.INSSEL = "AUTO";
    if (this.INSSEL === "ALL" && list.length < 2) this.INSSEL = "AUTO";
    sel.value = this.INSSEL;
    this.setIns(this.INSSEL, true);
  }
  setIns(v, quiet) {
    this.INSSEL = v;
    this.host.store.set("cc_ins", v);
    const { trades, cur } = focusOf(this.ALLTR, this.INSLIST, v, this.host.settings().symbol && this.host.settings().symbol !== "AUTO" ? this.host.settings().symbol : "MGC");
    this.TR = trades;
    const changed = cur.px !== this.CUR.px || cur.tv !== this.CUR.tv;
    this.CUR = cur;
    this.applyLabels();
    if (changed) this.refreshMarket();
    if (!quiet) {
      this.renderData();
      this.renderRisk();
    }
  }
  closed() {
    return closedOf(this.TR);
  }
  introStats() {
    const c = this.closed();
    if (!c.length) return null;
    const s = S(c);
    return { net: smoney(s.net), win: isFinite(s.win) ? (s.win * 100).toFixed(1) + "%" : "\u2014", pf: s.pf === Infinity ? "\u221E" : isFinite(s.pf) ? s.pf.toFixed(2) : "\u2014", n: String(s.n), dd: s.dd ? "-" + money(s.dd).replace("-", "") : "\u2014", r: isFinite(s.avgR) ? (s.avgR > 0 ? "+" : "") + s.avgR.toFixed(2) + "R" : "\u2014" };
  }
  // ================================================================== labels
  padL(a, b) {
    return a + " " + ".".repeat(Math.max(3, 29 - a.length - b.length)) + " " + b;
  }
  setTZLabels() {
    const c = cityOf(this.TZN);
    this.root.querySelectorAll("[data-tzl]").forEach((e) => e.textContent = e.dataset.tzl.replace("@", c));
  }
  applyLabels() {
    const set = (id, h) => {
      const e = this.$(id);
      if (e) e.innerHTML = h;
    };
    const C = this.CUR, pvTxt = money(C.pv).replace(".00", ""), tk = C.tick, tkD = Math.max(0, dec(tk));
    set("opSub", esc(this.NAME) + " \xB7 " + esc(C.code));
    set("chartHd", `${esc(C.fut ? C.code + "1!" : C.code)} \xB7 ${esc(C.name)} <span>${TV_LINK}</span>`);
    set("liveHd", `LIVE ${esc(C.short)} \xB7 ${esc(C.px.split(":").pop())} <span>5M \xB7 ${TV_LINK}</span>`);
    set("quoteHd", `${esc(C.short)} \xB7 LIVE <span>${esc(C.px.replace(":", " \xB7 "))}</span>`);
    set("newsHd", `${esc(C.short)} NEWS FEED <span>${TV_LINK} \xB7 LIVE</span>`);
    set("sentHd", `SENTIMENT \xB7 ${esc(C.px.split(":").pop())} <span>TECHNICAL RATING</span>`);
    set("posHd", `POSITION SIZE \xB7 ${esc(C.code)} <span>${esc(pvTxt)} / POINT</span>`);
    set("specK", `<span class="k">CONTRACT</span><span class="v">${esc(C.code)} \xB7 ${esc(C.name)}</span><span class="k">TICK</span><span class="v">${tk.toFixed(tkD)} = ${money(tk * C.pv)}</span><span class="k">POINT</span><span class="v">${esc(pvTxt)} / ${C.fut ? "CONTRACT" : "UNIT"}</span>`);
    ["pEn", "pSt"].forEach((id) => {
      const e = this.$(id);
      if (e) e.step = String(tk);
    });
    this.LOG[1] = this.padL("MOUNT /journal/" + C.code.toLowerCase(), "OK");
    this.LOG[5] = this.padL("DECRYPTING OPERATOR", this.NAME);
    this.setTZLabels();
  }
  setLink(ok, t) {
    this.$("linkDot").className = "dot" + (ok === true ? " ok" : ok === false ? " bad" : "");
    this.$("linkTxt").textContent = t;
  }
  // ================================================================== panels
  renderData() {
    this.life.after(0, () => this.renderGuard());
    const $ = this.$, c = this.closed(), s = S(c), Z = this.Z;
    $("kNet").textContent = smoney(s.net);
    $("kNet").className = "big " + cls(s.net);
    $("kWin").textContent = isFinite(s.win) ? (s.win * 100).toFixed(1) + "%" : "\u2014";
    $("kPF").textContent = s.pf === Infinity ? "\u221E" : isFinite(s.pf) ? s.pf.toFixed(2) : "\u2014";
    $("kR").textContent = isFinite(s.avgR) ? (s.avgR > 0 ? "+" : "") + s.avgR.toFixed(2) + "R" : "\u2014";
    $("kDD").textContent = s.dd ? "-" + money(s.dd).replace("-", "") : "\u2014";
    $("kN").textContent = s.n ? String(s.n) : "\u2014";
    const L = S(c.filter((t) => t.dir === "long")), Sh = S(c.filter((t) => t.dir === "short"));
    $("lsL").innerHTML = `<span class="${cls(L.net)}">${smoney(L.net)}</span> \xB7 ${L.n}`;
    $("lsS").innerHTML = `<span class="${cls(Sh.net)}">${smoney(Sh.net)}</span> \xB7 ${Sh.n}`;
    const tot = L.n + Sh.n || 1;
    $("lsBarL").style.width = L.n / tot * 100 + "%";
    $("lsBarS").style.width = Sh.n / tot * 100 + "%";
    const tk = Z.dayKey(/* @__PURE__ */ new Date()), td = c.filter((t) => Z.dayKey(t.time) === tk), tr = td.map((t) => t.r).filter(isFinite);
    $("tdN").textContent = String(td.length);
    const tn = td.reduce((a, t) => a + t.net, 0);
    $("tdNet").textContent = smoney(tn);
    $("tdNet").className = "v " + cls(tn);
    $("tdR").textContent = tr.length ? tr.reduce((a, b) => a + b, 0).toFixed(2) + "R" : "\u2014";
    const recent = [...c].reverse().slice(0, 7);
    $("feed").innerHTML = recent.length ? recent.map((t) => `<div><span class="t">${Z.local(t.time).toISOString().slice(11, 16)}</span><span>${t.dir === "long" ? "\u25B2" : "\u25BC"} ${esc(t.sym)} \xD7${isFinite(t.qty) ? t.qty : 1}</span><span class="${cls(t.net)}">${smoney(t.net)}</span></div>`).join("") : '<div class="note">No trades yet.</div>';
    $("logCount").textContent = c.length + " CLOSED";
    $("logT").innerHTML = `<tr><th>TIME (LOCAL)</th><th>SIDE</th><th class="n">QTY</th><th class="n">ENTRY</th><th class="n">EXIT</th><th class="n">PTS</th><th class="n">R</th><th>SETUP</th><th class="n">NET</th></tr>` + [...c].reverse().slice(0, 150).map((t) => `<tr><td>${Z.local(t.time).toISOString().slice(5, 16).replace("T", " ")}</td><td>${t.dir.toUpperCase()}</td><td class="n">${isFinite(t.qty) ? t.qty : "\u2014"}</td><td class="n">${isFinite(t.en) ? t.en.toFixed(1) : "\u2014"}</td><td class="n">${isFinite(t.ex) ? t.ex.toFixed(1) : "\u2014"}</td><td class="n ${cls(t.pts)}">${isFinite(t.pts) ? t.pts.toFixed(1) : "\u2014"}</td><td class="n ${cls(t.r)}">${isFinite(t.r) ? t.r.toFixed(2) : "\u2014"}</td><td>${esc(t.setup)}</td><td class="n ${cls(t.net)}">${smoney(t.net)}</td></tr>`).join("");
    this.renderCal();
    this.renderPsyche();
    this.brain.setLabels(brainLabels(c));
    this.drawStatic();
  }
  renderCal() {
    const c = this.closed(), Z = this.Z, days = {}, cnt = {};
    c.forEach((t) => {
      const k = Z.dayKey(t.time);
      days[k] = (days[k] || 0) + t.net;
      cnt[k] = (cnt[k] || 0) + 1;
    });
    if (!this.calM) {
      const d = c.length ? Z.local(c[c.length - 1].time) : Z.local(/* @__PURE__ */ new Date());
      this.calM = [d.getUTCFullYear(), d.getUTCMonth()];
    }
    const [y, m] = this.calM;
    this.$("calTitle").textContent = new Date(Date.UTC(y, m, 1)).toLocaleString("en-US", { month: "short", year: "numeric", timeZone: "UTC" }).toUpperCase();
    let h = ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"].map((d) => `<div style="min-height:0;border:0;text-align:center">${d}</div>`).join("");
    const f = (new Date(Date.UTC(y, m, 1)).getUTCDay() + 6) % 7, n2 = new Date(Date.UTC(y, m + 1, 0)).getUTCDate();
    for (let i = 0; i < f; i++) h += '<div style="border:0"></div>';
    for (let d = 1; d <= n2; d++) {
      const k = `${y}-${String(m + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`, v = days[k];
      h += `<div class="${v > 0 ? "g" : v < 0 ? "r" : ""}">${d}${v != null ? `<b class="${cls(v)}">${smoney(v).replace(".00", "")}</b>${cnt[k]}T` : ""}</div>`;
    }
    this.$("cal").innerHTML = h;
  }
  renderPsyche() {
    const c = this.closed(), Z = this.Z;
    if (!c.length) {
      this.$("psyche").innerHTML = '<div class="note">Connect your LEDGR key to build the report from your trades.</div>';
      return;
    }
    const sess = groupBy(c, (t) => sessOf(t.tin || t.time)), setups = groupBy(c, (t) => t.setup);
    const hours = groupBy(c, (t) => String(Z.local(t.tin || t.time).getUTCHours()).padStart(2, "0") + ":00");
    const dows = groupBy(c, (t) => ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"][Z.local(t.time).getUTCDay()]);
    const { tilt, bigL } = behaviour(c);
    const line = (lbl, val, txt) => `<tr><td style="color:var(--mut);width:160px">${lbl}</td><td>${val}</td><td style="color:var(--mut)">${txt || ""}</td></tr>`;
    const last = (a) => a[a.length - 1];
    this.$("psyche").innerHTML = `<table>${line("STRONGEST SESSION", `<span class="up">${sess[0].k}</span>`, smoney(sess[0].net) + " \xB7 " + sess[0].n + " trades")}${line("WEAKEST SESSION", `<span class="down">${last(sess).k}</span>`, smoney(last(sess).net))}
    ${line("BEST SETUP", `<span class="up">${esc(setups[0].k)}</span>`, smoney(setups[0].net) + " \xB7 win " + (isFinite(setups[0].win) ? (setups[0].win * 100).toFixed(0) : "\u2014") + "%")}${line("WORST SETUP", `<span class="down">${esc(last(setups).k)}</span>`, smoney(last(setups).net))}
    ${line("BEST HOUR (LOCAL)", hours[0].k, smoney(hours[0].net))}${line("WORST HOUR (LOCAL)", last(hours).k, smoney(last(hours).net))}${line("BEST DAY", dows[0].k, smoney(dows[0].net))}
    ${line("QUICK RE-ENTRIES AFTER A LOSS", tilt, "trades within 20 min of a losing trade")}${line("LOSSES BEYOND -1.2R", bigL, "stops not respected")}</table>
    <div class="note" style="margin-top:12px">Worked out from your LEDGR trades. Patterns need a decent sample, so read these as hints rather than verdicts.</div>`;
  }
  drawStatic() {
    const c = this.closed(), Z = this.Z;
    let eq = 0;
    const all = c.map((t) => eq += t.net);
    const since = Date.now() - 30 * 864e5;
    let e2 = 0;
    const last30 = c.filter((t) => +t.time >= since).map((t) => e2 += t.net);
    lineChart(this.$("spark"), last30.length > 1 ? last30 : all.slice(-40));
    if (this.$("v-perf").classList.contains("on")) {
      lineChart(this.$("eqCv"), all, c.length ? [Z.dayKey(c[0].time), Z.dayKey(c[c.length - 1].time)] : null);
      const grp = (f) => {
        const m = {};
        c.forEach((t) => {
          const k = f(t);
          m[k] = (m[k] || 0) + t.net;
        });
        return Object.entries(m).map(([k, v]) => ({ k, v }));
      };
      const bySess = grp((t) => sessOf(t.tin || t.time));
      barChart(this.$("sessCv"), ["ASIA", "LONDON", "NEW YORK"].map((k) => ({ k, v: (bySess.find((r) => r.k === k) || { v: 0 }).v })).filter(() => c.length > 0));
      barChart(this.$("setupCv"), grp((t) => t.setup).sort((a, b) => b.v - a.v).slice(0, 8));
    }
  }
  // ================================================================== tabs, clock, loop
  wire() {
    const { root, life, $ } = this;
    $("tabs").onclick = (e) => {
      const t = e.target.closest(".tab");
      if (t) this.openTab(t);
    };
    $("calPrev").onclick = () => {
      const m = this.calM;
      this.calM = m[1] ? [m[0], m[1] - 1] : [m[0] - 1, 11];
      this.renderCal();
    };
    $("calNext").onclick = () => {
      const m = this.calM;
      this.calM = m[1] < 11 ? [m[0], m[1] + 1] : [m[0] + 1, 0];
      this.renderCal();
    };
    $("insSel").onchange = () => this.setIns($("insSel").value);
    $("refreshBtn").onclick = () => void this.load(true);
    $("replayBtn").onclick = () => this.intro.showGate();
    $("keyBtn").onclick = () => this.host.openSettings();
    root.querySelector('[data-action="vault"]').onclick = (e) => {
      e.preventDefault();
      this.host.openVaultHome();
    };
    $("guardChip").onclick = () => this.openTab(root.querySelector('.tab[data-v="risk"]'));
    $("sndBtn").onclick = () => {
      const on = !this.sound.pref;
      this.sound.pref = on;
      this.host.setSound(on);
      this.sound.on = on && !!this.sound.AC;
      this.setSndBtn();
      if (on) {
        this.sound.audio();
        void this.sound.AC?.resume();
        this.sound.on = true;
        this.sound.blip();
      }
    };
    $("ffBtn").onclick = $("ffTick").onclick = $("ffLogo").onclick = (e) => {
      e.preventDefault();
      $("ffPanel").classList.toggle("on");
      this.ffList();
    };
    life.on(root, "click", (e) => {
      const t = e.target;
      if ($("ffPanel").classList.contains("on") && !t.closest("#ffPanel,#ff")) $("ffPanel").classList.remove("on");
      if (t.closest(".ic,.chip,.btn,.ck")) this.sound.blip();
    });
    root.querySelectorAll(".fffil .chip[data-c]").forEach((c) => c.onclick = () => {
      this.FFC = c.dataset.c;
      root.querySelectorAll(".fffil .chip[data-c]").forEach((x) => x.classList.toggle("on", x === c));
      this.ffRunKey = "";
      this.ffRender();
      this.ffList();
    });
    root.querySelectorAll(".fffil .chip[data-i]").forEach((c) => c.onclick = () => {
      this.FFI = +c.dataset.i;
      root.querySelectorAll(".fffil .chip[data-i]").forEach((x) => x.classList.toggle("on", x === c));
      this.ffRunKey = "";
      this.ffRender();
      this.ffList();
    });
    life.on(root, "pointerdown", () => {
      this.sound.unlock();
      if (!root.contains(root.ownerDocument.activeElement)) root.focus({ preventScroll: true });
    }, true);
    life.on(root, "keydown", (e) => {
      const target = e.target;
      if (target.closest("input,textarea,select") || this.intro.isRunning() || e.metaKey || e.ctrlKey || e.altKey) return;
      const tabs = Array.from(root.querySelectorAll(".tab")), i = +e.key - 1;
      if (i >= 0 && i < tabs.length) {
        e.preventDefault();
        this.openTab(tabs[i]);
      }
    });
    let rz = 0;
    const ro = new life.win.ResizeObserver(() => {
      this.fitStage();
      life.clear(rz);
      rz = life.after(150, () => this.drawStatic());
    });
    ro.observe(root);
    life.on(life.win, "online", () => this.refreshMarket(true));
    life.on(life.win, "offline", () => this.refreshMarket(true));
    this.disconnectObserver = () => ro.disconnect();
  }
  /** Scale the stage so the layout never gets shorter than 900 px or narrower than 1400 px. */
  fitStage() {
    const W = this.root.clientWidth, H = this.root.clientHeight;
    if (!W || !H) return;
    const k = Math.min(1, H / DESIGN_H, W / DESIGN_W);
    this.stage.setCssStyles({ width: `${W / k}px`, height: `${H / k}px`, transform: k < 1 ? `scale(${k})` : "" });
  }
  openTab(t) {
    const { root } = this;
    root.querySelectorAll(".tab").forEach((x) => x.classList.toggle("on", x === t));
    root.querySelectorAll(".view").forEach((v) => v.classList.toggle("on", v.id === "v-" + t.dataset.v));
    if (t.dataset.v === "chart") this.loadChart();
    if (t.dataset.v === "news") this.loadNews();
    if (t.dataset.v === "risk") this.renderRisk();
    this.drawStatic();
    this.sound.blip();
  }
  tick() {
    const $ = this.$, now = /* @__PURE__ */ new Date(), Z = this.Z;
    $("clock").textContent = fmtT(this.TZN);
    $("nyT").textContent = fmtT("America/New_York");
    $("ldT").textContent = fmtT("Europe/London");
    $("tkT").textContent = fmtT("Asia/Tokyo");
    $("dateTxt").textContent = Z.local(now).toISOString().slice(0, 10).split("-").reverse().join(".");
    $("todayDate").textContent = $("dateTxt").textContent;
    $("mkLocal").textContent = "LOCAL " + fmtT(this.TZN) + " \xB7 NY " + fmtT("America/New_York");
    const o = cmeOpen();
    $("cmeState").textContent = o ? "OPEN" : "CLOSED";
    $("cmeState").className = "big " + (o ? "up" : "down");
    $("cmeNext").textContent = cmeNext();
    this.$("sessNow").textContent = sessOf(/* @__PURE__ */ new Date());
  }
  loop(t) {
    const shown = this.root.getClientRects().length > 0;
    if (shown) {
      if (this.$("v-main").classList.contains("on")) {
        this.brain.draw(t);
        this.drawFig(t);
      }
      if (this.$("v-markets").classList.contains("on")) this.drawGlobe(t);
      this.drawRadar(t);
    }
    this.life.frame((x) => this.loop(x));
  }
  powerOn() {
    const els = Array.from(this.root.querySelectorAll(".panel:not(#ffPanel),.tab,.ic,.brand")).filter((el) => el.offsetParent !== null);
    els.forEach((el, i) => {
      el.classList.remove("pwr");
      void el.offsetWidth;
      el.style.animationDelay = i * 38 + "ms";
      el.classList.add("pwr");
    });
    this.life.after(els.length * 38 + 700, () => els.forEach((el) => {
      el.classList.remove("pwr");
      el.style.animationDelay = "";
    }));
  }
  setSndBtn() {
    this.$("sndBtn").textContent = this.sound.pref ? "SND ON" : "SND OFF";
  }
  // ================================================================== economic calendar
  async calLoad() {
    const s = await this.host.calendar();
    if (!this.life.alive) return;
    this.cal = s;
    this.FF = s.kind === "ok" ? s.events : null;
    const src = this.$("calSrc");
    if (s.kind === "ok" && s.source) {
      src.textContent = `${s.source.name.toUpperCase()} \u2197`;
      src.href = s.source.url;
      src.style.display = "";
    }
    this.ffRunKey = "";
    this.ffRender();
    this.ffList();
    this.renderHi();
  }
  ffRender() {
    const tick = this.$("ffTick");
    if (!this.FF) {
      const t = calendarText(this.cal).ticker;
      if (tick.textContent !== t) {
        tick.empty();
        tick.createSpan({ cls: "ffmut", text: t });
      }
      return;
    }
    const now = Date.now(), ev = this.FF.filter(this.ffPass), next = ev.find((e) => +e.t > now), just = ev.filter((e) => now - +e.t < 30 * 6e4 && +e.t <= now);
    const impDots = (n2) => "\u25CF".repeat(n2) + "\u25CB".repeat(3 - n2);
    let head = "";
    if (next) {
      const ms = +next.t - now, warn = next.i === 3 && ms < 15 * 6e4;
      head = `<span class="ffnext ${warn ? "ffwarn" : ""}">${warn ? "\u26A0 " : ""}NEXT <b>${esc(next.country)} ${esc(next.title)}</b> <span class="imp">${impDots(next.i)}</span> IN <b>${cd(ms)}</b>${next.forecast ? ` \xB7 F ${esc(next.forecast)}` : ""}${next.previous ? ` \xB7 P ${esc(next.previous)}` : ""}</span>`;
    } else head = '<span class="ffnext ffmut">NO MORE EVENTS THIS WEEK</span>';
    const today = this.Z.dayKey(/* @__PURE__ */ new Date()), rest = ev.filter((e) => this.Z.dayKey(e.t) === today && e !== next);
    const runKey = rest.map((e) => e.title + e.date).join("|") + just.length;
    const items = [
      ...just.map((e) => `<span style="margin-right:28px">JUST RELEASED \xB7 <b>${esc(e.country)} ${esc(e.title)}</b> ${this.hhmm(e.t)}</span>`),
      ...rest.map((e) => `<span style="margin-right:28px" class="${+e.t < now ? "ffmut" : ""}">${this.hhmm(e.t)} <span class="imp">${impDots(e.i)}</span><b>${esc(e.country)}</b> ${esc(e.title)}${e.forecast ? " \xB7 F " + esc(e.forecast) : ""}</span>`)
    ];
    let hd = tick.querySelector(".ffhead");
    if (!hd) {
      tick.innerHTML = '<span class="ffhead" style="position:relative;z-index:1;background:rgba(14,14,14,.95);padding-right:10px"></span><span class="ffrunwrap" style="position:absolute;left:0;right:0;top:0;bottom:0;overflow:hidden"></span>';
      hd = tick.querySelector(".ffhead");
    }
    hd.innerHTML = head;
    const wrap = tick.querySelector(".ffrunwrap");
    wrap.style.left = hd.offsetWidth + 8 + "px";
    if (runKey !== this.ffRunKey) {
      this.ffRunKey = runKey;
      wrap.innerHTML = items.length ? `<span class="ffrun">${items.join("")}</span>` : '<span class="ffmut" style="line-height:28px">TODAY: NOTHING ELSE SCHEDULED</span>';
      wrap.style.lineHeight = "28px";
    }
    const up = this.cal.kind === "ok" ? this.cal.updatedAt : null;
    this.$("ffUpd").textContent = up ? "UPDATED " + this.Z.local(new Date(up)).toISOString().slice(5, 16).replace("T", " ") + (this.cal.kind === "ok" && this.cal.stale ? " \xB7 STALE" : "") : "";
  }
  ffList() {
    const list = this.$("ffList");
    if (!this.FF) {
      list.empty();
      list.createDiv({ cls: "note", text: calendarText(this.cal).list });
      return;
    }
    const now = Date.now(), ev = this.FF.filter(this.ffPass), impDots = (n2) => "\u25CF".repeat(n2) + "\u25CB".repeat(3 - n2);
    let h = '<div class="ev hd"><span>TIME</span><span>CUR</span><span>IMP</span><span>EVENT</span><span>FCST</span><span>PREV</span></div>', day = "";
    ev.forEach((e) => {
      const d = this.Z.local(e.t).toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "short", timeZone: "UTC" }).toUpperCase();
      if (d !== day) {
        day = d;
        h += `<div class="day">${d}</div>`;
      }
      const ms = +e.t - now;
      h += `<div class="ev ${ms < 0 ? "past" : ms < 60 * 6e4 ? "soon" : ""}"><span>${this.hhmm(e.t)}</span><span>${esc(e.country)}</span><span class="imp">${impDots(e.i)}</span><span>${esc(e.title)}</span><span>${esc(e.forecast || "")}</span><span>${esc(e.previous || "")}</span></div>`;
    });
    list.innerHTML = ev.length ? h : '<div class="note">No events match these filters.</div>';
  }
  renderHi() {
    const el = this.$("hiList");
    if (!el) return;
    if (!this.FF) {
      el.empty();
      el.createDiv({ cls: "note", text: calendarText(this.cal).list });
      return;
    }
    const now = Date.now(), ev = this.FF.filter((e) => e.i === 3 && +e.t > now - 30 * 6e4).slice(0, 14);
    el.innerHTML = ev.length ? ev.map((e) => {
      const ms = +e.t - now;
      return `<div class="feed"><div><span class="t">${this.Z.local(e.t).toISOString().slice(5, 16).replace("T", " ")}</span><span><b style="font-weight:400;color:#fff">${esc(e.country)}</b> ${esc(e.title)}</span><span class="${ms < 36e5 && ms > 0 ? "ffwarn" : ""}">${ms > 0 ? cd(ms) : "OUT"}</span></div></div>`;
    }).join("") : '<div class="note">No high-impact events left this week.</div>';
  }
  // ================================================================== toasts + news alerts
  toast(title, bodyHtml, hi) {
    const box = this.$("toasts"), d = box.createDiv({ cls: "toast" + (hi ? " hi" : "") });
    d.createEl("b", { text: title });
    d.insertAdjacentHTML("beforeend", bodyHtml);
    d.onclick = () => d.remove();
    box.prepend(d);
    this.life.after(hi ? 2e4 : 12e3, () => d.remove());
    while (box.children.length > 4) box.lastChild.remove();
  }
  checkAlerts() {
    if (!this.FF) return;
    const now = Date.now();
    this.FF.forEach((e) => {
      if (e.i < 3) return;
      if (!(this.CUR.ccy.includes(e.country) || this.FFC === "ALL" || e.country === this.FFC)) return;
      const k = e.title + e.date, rem = +e.t - now, prev = this.ALERT_PREV[k];
      this.ALERT_PREV[k] = rem;
      for (const m of crossed(prev, rem)) {
        const det = `<span class="ffmut">${esc(e.country)}</span> ${esc(e.title)}${e.forecast ? ` \xB7 F ${esc(e.forecast)}` : ""}${e.previous ? ` \xB7 P ${esc(e.previous)}` : ""}`;
        if (m) this.toast(`HIGH IMPACT IN ${m} MIN`, det, m <= 5);
        else this.toast("RELEASED NOW", det, true);
        this.sound.alarm(m ? m <= 5 ? 3 : 2 : 4);
      }
    });
  }
  // ================================================================== risk: guard, checklist, sizing
  todayTrades() {
    const k = this.Z.dayKey(/* @__PURE__ */ new Date());
    return this.closed().filter((t) => this.Z.dayKey(t.time) === k);
  }
  bar(label, val, max, txt) {
    const f = Math.max(0, Math.min(1, max ? val / max : 0));
    return `<div class="gbar ${f >= 1 ? "bad" : f >= 0.7 ? "warn" : ""}"><div class="l"><span>${label}</span><span>${txt}</span></div><div class="t"><i style="width:${(f * 100).toFixed(0)}%"></i></div></div>`;
  }
  renderGuard() {
    const $ = this.$, RG = this.RG, g = guardState(this.todayTrades(), RG, Date.now());
    $("guardChip").className = "gchip " + g.lvl.toLowerCase();
    $("guardChip").textContent = "GUARD \xB7 " + g.lvl;
    $("gMini").textContent = g.lvl === "OK" ? "CLEAR" : g.lvl;
    $("rgSub").textContent = g.why[0] ? g.why[0].toUpperCase() : "TODAY";
    const bars = this.bar("LOSS TODAY", Math.max(0, -g.net), RG.loss, `${money(Math.max(0, -g.net))} / ${money(RG.loss)}`) + this.bar("TRADES", g.n, RG.trades, `${g.n} / ${RG.trades}`) + this.bar("LOSSES IN A ROW", g.consec, RG.consec, `${g.consec} / ${RG.consec}`) + (RG.cool ? this.bar("COOL-DOWN", g.coolLeft, RG.cool * 6e4, g.coolLeft ? cd(g.coolLeft) : "READY") : "");
    $("gMiniBars").innerHTML = bars;
    if ($("v-risk").classList.contains("on")) {
      $("gBig").textContent = g.lvl === "OK" ? "CLEAR" : g.lvl;
      $("gBig").className = "gbig " + (g.lvl === "STOP" ? "stop" : "");
      $("gWhy").textContent = g.why.join(" \xB7 ") || "Within your limits";
      $("gBars").innerHTML = bars;
    }
    if (this.lastLevel && g.lvl !== this.lastLevel && g.lvl === "STOP") {
      this.toast("STOP TRADING", esc(g.why.join(" \xB7 ")), true);
      this.sound.alarm(5);
    } else if (this.lastLevel === "OK" && g.lvl === "CAUTION") {
      this.toast("CAUTION", esc(g.why.join(" \xB7 ")), false);
      this.sound.alarm(1);
    }
    this.lastLevel = g.lvl;
  }
  ckKey() {
    return "cc_ck_" + this.Z.dayKey(/* @__PURE__ */ new Date());
  }
  renderCk() {
    const day = this.ckKey(), st = this.host.store.get(day, {}), nc = newsClear(this.FF, this.CUR.ccy, Date.now());
    const note = nc === null ? calendarText(this.cal).checklist : "";
    let h = `<div class="ck auto ${nc ? "on" : ""}"><span class="b">${nc ? "\u2713" : nc === null ? "?" : "\u2715"}</span><span class="t">No high-impact ${esc(this.CUR.ccy.join("/"))} news in the next 30 min${esc(note)}</span><span class="x" style="cursor:default">AUTO</span></div>`;
    this.CK.forEach((c, i) => {
      h += `<div class="ck ${st[i] ? "on" : ""}" data-i="${i}"><span class="b">${st[i] ? "\u2713" : ""}</span><span class="t">${esc(c)}</span><span class="x" data-del="${i}" title="Remove">\u2715</span></div>`;
    });
    const all = !!nc && this.CK.every((_, i) => st[i]);
    h += `<div class="ckst ${all ? "go" : ""}">${all ? "CLEARED TO TRADE" : "NOT CLEARED"}</div><div style="display:flex;gap:6px"><span class="chip" id="ckAdd">+ ADD ITEM</span><span class="chip" id="ckReset">RESET TODAY</span><span class="chip" id="ckDef">DEFAULT LIST</span></div>`;
    const list = this.$("ckList");
    list.innerHTML = h;
    this.$("ckState").textContent = all ? "CLEARED" : "PENDING";
    list.querySelectorAll(".ck[data-i]").forEach((el) => el.onclick = (e) => {
      const del = e.target.dataset.del;
      if (del != null) {
        this.CK.splice(+del, 1);
        this.host.store.set("cc_ck_items", this.CK);
        this.host.store.set(day, {});
        this.renderCk();
        return;
      }
      const s2 = this.host.store.get(day, {});
      s2[el.dataset.i] = !s2[el.dataset.i];
      this.host.store.set(day, s2);
      this.renderCk();
    });
    this.$("ckAdd").onclick = async () => {
      const t = await this.host.ask("New checklist item");
      if (t && t.trim()) {
        this.CK.push(t.trim());
        this.host.store.set("cc_ck_items", this.CK);
        this.renderCk();
      }
    };
    this.$("ckReset").onclick = () => {
      this.host.store.set(day, {});
      this.renderCk();
    };
    this.$("ckDef").onclick = () => {
      this.CK = CK_DEF.slice();
      this.host.store.set("cc_ck_items", this.CK);
      this.host.store.set(day, {});
      this.renderCk();
    };
  }
  renderPos() {
    const out = this.$("pOut"), C = this.CUR;
    const r = sizeFor(C, { acc: +this.PS.acc, pct: +this.PS.pct, fee: +this.PS.fee, max: +this.PS.max }, parseFloat(this.$("pEn").value), parseFloat(this.$("pSt").value));
    if (!r) {
      out.innerHTML = '<div class="note" style="margin-top:12px">Enter an entry and a stop price.</div>';
      return;
    }
    const pd = Math.max(1, dec(C.tick)), tgt = (x) => r.target(x).toFixed(pd);
    out.innerHTML = `<div class="pbig">${r.contracts}<small>CONTRACTS \xB7 ${r.dir}</small></div>${r.capped ? '<div class="sub" style="text-align:center">capped at your max contracts</div>' : ""}${r.contracts === 0 ? '<div class="sub" style="text-align:center">stop too wide for this risk \u2014 size 0</div>' : ""}
   <div class="pres"><span class="k">Stop distance</span><span class="v">${r.dist.toFixed(pd)} pts \xB7 ${r.ticks} ticks</span><span class="k">Risk per contract</span><span class="v">${money(r.perContract)}</span>
   <span class="k">Planned risk (${+this.PS.pct}%)</span><span class="v">${money(r.planned)}</span><span class="k">Actual risk</span><span class="v">${money(r.actual)}</span>
   <span class="k">1R target</span><span class="v">${tgt(1)} \xB7 +${money(r.reward(1))}</span><span class="k">2R target</span><span class="v">${tgt(2)} \xB7 +${money(r.reward(2))}</span><span class="k">3R target</span><span class="v">${tgt(3)} \xB7 +${money(r.reward(3))}</span></div>`;
  }
  renderRisk() {
    this.renderCk();
    this.renderGuard();
    this.renderPos();
  }
  initRisk() {
    const bind = (id, obj, key, save, fn) => {
      const el = this.$(id);
      el.value = String(obj[key] ?? "");
      el.oninput = () => {
        obj[key] = el.value === "" ? "" : +el.value;
        this.host.store.set(save, obj);
        fn();
      };
    };
    const RG = this.RG, PS = this.PS;
    bind("gLoss", RG, "loss", "cc_guard", () => this.renderGuard());
    bind("gTrades", RG, "trades", "cc_guard", () => this.renderGuard());
    bind("gConsec", RG, "consec", "cc_guard", () => this.renderGuard());
    bind("gCool", RG, "cool", "cc_guard", () => this.renderGuard());
    bind("pAcc", PS, "acc", "cc_pos", () => this.renderPos());
    bind("pPct", PS, "pct", "cc_pos", () => this.renderPos());
    bind("pFee", PS, "fee", "cc_pos", () => this.renderPos());
    bind("pMax", PS, "max", "cc_pos", () => this.renderPos());
    bind("pEn", PS, "en", "cc_pos", () => this.renderPos());
    bind("pSt", PS, "st", "cc_pos", () => this.renderPos());
    this.renderRisk();
    this.life.every(1e3, () => {
      this.renderGuard();
      if (this.$("v-news").classList.contains("on")) this.renderHi();
      if (this.$("v-risk").classList.contains("on")) this.renderCk();
    });
  }
  // ================================================================== TradingView
  liveOk() {
    return this.host.settings().tvWidgets && navigator.onLine;
  }
  offlineNote(el, pad = false) {
    el.empty();
    const n2 = el.createDiv({ cls: "note", text: "Live market data needs an internet connection." });
    if (pad) n2.style.padding = "20px";
  }
  loadWidgets() {
    if (this.widgetsLoaded) return;
    this.widgetsLoaded = true;
    const C = this.CUR, $ = this.$;
    if (!this.liveOk()) {
      ["tape", "goldQuote", "liveChart"].forEach((id) => this.offlineNote($(id)));
      return;
    }
    mountWidget($("tape"), "ticker-tape", { symbols: [{ proName: C.px, title: C.short }].concat([{ proName: "OANDA:XAUUSD", title: "GOLD" }, { proName: "CAPITALCOM:DXY", title: "DXY" }, { proName: "OANDA:XAGUSD", title: "SILVER" }, { proName: "FOREXCOM:SPXUSD", title: "S&P 500" }, { proName: "FOREXCOM:NSXUSD", title: "NASDAQ" }, { proName: "FX:EURUSD", title: "EURUSD" }, { proName: "FX:USDJPY", title: "USDJPY" }, { proName: "BITSTAMP:BTCUSD", title: "BTC" }].filter((x) => x.proName !== C.px)), showSymbolLogo: false, isTransparent: false, displayMode: "adaptive", colorTheme: "dark", locale: "en" });
    mountWidget($("goldQuote"), "single-quote", { symbol: C.px, width: "100%", isTransparent: false, colorTheme: "dark", locale: "en" });
    mountWidget($("liveChart"), "advanced-chart", { autosize: true, symbol: C.px, interval: "5", timezone: this.TZN, theme: "dark", style: "1", locale: "en", hide_top_toolbar: true, hide_legend: false, allow_symbol_change: false, save_image: false, hide_volume: true, backgroundColor: "rgba(8,8,8,1)", gridColor: "rgba(255,255,255,0.05)", support_host: "https://www.tradingview.com" });
  }
  loadNews() {
    this.renderHi();
    if (this.newsLoaded) return;
    this.newsLoaded = true;
    const C = this.CUR, $ = this.$;
    if (!this.liveOk()) {
      ["newsFeed", "sentiment"].forEach((id) => this.offlineNote($(id)));
      return;
    }
    mountWidget($("newsFeed"), "timeline", { feedMode: "symbol", symbol: C.px, isTransparent: true, displayMode: "regular", width: "100%", height: "100%", colorTheme: "dark", locale: "en" });
    mountWidget($("sentiment"), "technical-analysis", { interval: "15m", width: "100%", height: "100%", isTransparent: true, symbol: C.px, showIntervalTabs: true, displayMode: "single", locale: "en", colorTheme: "dark" });
  }
  loadChart() {
    if (this.chartLoaded) return;
    this.chartLoaded = true;
    const box = this.$("tvbox");
    if (!this.liveOk()) {
      this.offlineNote(box, true);
      return;
    }
    const id = "tradingview_" + Math.random().toString(16).slice(2, 7);
    mountChart(box, chartUrl({
      symbol: this.CUR.tv,
      interval: "5",
      timezone: this.TZN,
      theme: "dark",
      style: "1",
      locale: "en",
      backgroundColor: "rgba(12,12,12,1)",
      gridColor: "rgba(122,122,122,0.25)",
      hide_side_toolbar: false,
      allow_symbol_change: true,
      withdateranges: true,
      frameId: id,
      overrides: { "mainSeriesProperties.candleStyle.upColor": "#e8e8e8", "mainSeriesProperties.candleStyle.downColor": "#ffffff", "mainSeriesProperties.candleStyle.borderUpColor": "#e8e8e8", "mainSeriesProperties.candleStyle.borderDownColor": "#ffffff", "mainSeriesProperties.candleStyle.wickUpColor": "#e8e8e8", "mainSeriesProperties.candleStyle.wickDownColor": "#ffffff" }
    }), id);
  }
  /** Rebuild the widgets for a new instrument, or after going on/offline or changing the setting. */
  refreshMarket(force = false) {
    if (this.widgetsLoaded) {
      this.widgetsLoaded = false;
      this.loadWidgets();
    }
    if (this.newsLoaded) {
      this.newsLoaded = false;
      if (this.$("v-news").classList.contains("on") || force) this.loadNews();
    }
    if (this.chartLoaded) {
      this.chartLoaded = false;
      if (this.$("v-chart").classList.contains("on") || force) this.loadChart();
    }
  }
};

// src/state.ts
function mode(hasKey, last) {
  if (!hasKey) return { kind: "connect" };
  if (last && !last.ok && (last.errorKind === "invalid_key" || last.errorKind === "not_pro")) return { kind: "locked", reason: last.errorKind, message: last.message ?? "" };
  if (last && !last.ok && last.errorKind === "no_journal") return { kind: "no_journal", message: last.message ?? "" };
  return { kind: "cc" };
}

// src/view.ts
var VIEW_TYPE = "ledgr-command-center";
var CommandCenterView = class extends import_obsidian3.ItemView {
  constructor(leaf, plugin) {
    super(leaf);
    this.plugin = plugin;
    this.cc = null;
    this.shown = null;
  }
  getViewType() {
    return VIEW_TYPE;
  }
  getDisplayText() {
    return "LEDGR Command Center";
  }
  getIcon() {
    return "activity";
  }
  async onOpen() {
    await this.plugin.loadCache();
    this.register(this.plugin.subscribe((what) => {
      if (what === "settings") this.cc?.applySettings();
      else this.render();
    }));
    this.render();
  }
  async onClose() {
    this.unmountCc();
    this.contentEl.empty();
  }
  render() {
    const m = mode(!!this.plugin.getKey(), this.plugin.last);
    if (m.kind === "cc" && this.shown === "cc") return;
    this.unmountCc();
    this.shown = m.kind;
    const el = this.contentEl;
    el.empty();
    el.removeClass("ledgr-cc");
    if (m.kind === "cc") {
      this.cc = new CommandCenter(el, {
        settings: () => this.plugin.cfg(),
        setSound: (on) => void this.plugin.updateSettings({ sound: on }),
        store: this.plugin.store,
        name: () => this.plugin.data.me?.journal?.displayName ?? null,
        cached: () => this.plugin.cachedTrades(),
        sync: (full) => this.plugin.sync(full),
        calendar: () => this.plugin.calendar(),
        videoUrl: () => this.plugin.videoUrl(),
        openSettings: () => this.plugin.openSettings(),
        openVaultHome: () => void this.plugin.openVaultHome(),
        ask: (t) => this.plugin.ask(t)
      });
      this.cc.mount();
      return;
    }
    const box = el.createDiv({ cls: "ledgr-lock" });
    if (m.kind === "connect") return this.screen(box, "plug", "Connect LEDGR", "Connect your LEDGR account to load your journal into the Command Center.", [["Connect with LEDGR", () => void this.plugin.connectWithLedgr().then(() => this.render())], ["Open settings", () => this.plugin.openSettings()]]);
    if (m.kind === "no_journal") return this.screen(box, "cloud-off", "No journal in the cloud yet", m.message, [["Try again", () => void this.retry()]]);
    const invalid = m.reason === "invalid_key";
    this.screen(
      box,
      "lock",
      invalid ? "API key not accepted" : "LEDGR Pro required",
      invalid ? `${m.message} Create a new key in LEDGR \u2192 Settings \u2192 API.` : `${m.message} The Command Center comes with LEDGR Pro.`,
      invalid ? [["Open settings", () => this.plugin.openSettings()], ["Try again", () => void this.retry()]] : [["Upgrade to LEDGR Pro", () => window.open(UPGRADE_URL)], ["Try again", () => void this.retry()]],
      "locked"
    );
  }
  async retry() {
    await this.plugin.sync(false);
    this.render();
  }
  unmountCc() {
    this.cc?.unmount();
    this.cc = null;
    this.shown = null;
  }
  screen(el, icon, title, body, actions, cls2 = "") {
    const box = el.createDiv({ cls: `ledgr-lock-screen ${cls2}` });
    (0, import_obsidian3.setIcon)(box.createDiv({ cls: "ledgr-lock-screen-icon" }), icon);
    box.createEl("h3", { text: title });
    if (body) box.createEl("p", { text: body });
    const row = box.createDiv({ cls: "ledgr-lock-actions" });
    actions.forEach(([label, fn], i) => {
      const b = row.createEl("button", { text: label, cls: i === 0 ? "mod-cta" : "" });
      b.onclick = fn;
    });
  }
};

// src/main.ts
var SECRET_ID = "ledgr-api-key";
var VIDEO_FILE = "operator.mp4";
var VIDEO_URL = "";
var DEFAULT_SETTINGS = { timezone: "", symbol: "AUTO", sound: true, intro: true, tvWidgets: true, notesFolder: "LEDGR", notesAuto: 0, ownWindow: true };
var DEFAULT_DATA = { settings: DEFAULT_SETTINGS, me: null, cc: {}, calendar: null, accounts: {}, starterAsked: false };
var transport = async (req) => {
  const res = await (0, import_obsidian4.requestUrl)({ url: req.url, method: req.method, headers: req.headers, body: req.body, throw: false });
  let json = null;
  try {
    json = res.json;
  } catch {
  }
  return { status: res.status, headers: res.headers, json };
};
var LedgrPlugin = class extends import_obsidian4.Plugin {
  constructor() {
    super(...arguments);
    this.data = structuredClone(DEFAULT_DATA);
    this.last = null;
    this.cache = null;
    this.running = null;
    this.listeners = /* @__PURE__ */ new Set();
    this.saveTimer = 0;
    /** Command-center state, saved shortly after each change. */
    this.store = {
      get: (key, fallback) => key in this.data.cc ? structuredClone(this.data.cc[key]) : fallback,
      set: (key, value) => {
        this.data.cc[key] = structuredClone(value);
        window.clearTimeout(this.saveTimer);
        this.saveTimer = window.setTimeout(() => void this.saveData(this.data), 400);
      }
    };
    // ------------------------------------------------------------------ trades as notes
    this.notesTimer = 0;
    this.notesRunning = null;
    /** Steps of the connect flow, for the modal. */
    this.connectSteps = {
      start: () => startConnect(transport, `Obsidian (${this.app.vault.getName()})`.slice(0, 40)),
      wait: (code, cancelled) => waitForKey({ code, poll: (d) => pollConnect(transport, d), sleep: (ms) => new Promise((r) => window.setTimeout(r, ms)), now: Date.now, cancelled }),
      finish: async (key) => {
        this.setKey(key);
        this.data.me = await this.client.me({ fresh: true });
        await this.saveData(this.data);
        void this.sync(false);
      }
    };
  }
  async onload() {
    const saved = await this.loadData() ?? {};
    this.data = { ...structuredClone(DEFAULT_DATA), ...saved, settings: { ...DEFAULT_SETTINGS, ...saved.settings ?? {} } };
    this.pruneChecklists();
    this.client = new LedgrClient({ transport, getKey: () => this.getKey() });
    this.registerView(VIEW_TYPE, (leaf) => new CommandCenterView(leaf, this));
    this.addRibbonIcon("activity", "Open LEDGR Command Center", () => void this.openView());
    this.addCommand({ id: "open-command-center", name: "Open Command Center", callback: () => void this.openView() });
    this.addCommand({ id: "sync", name: "Sync trades now", callback: () => void this.sync(true) });
    this.addCommand({ id: "sync-notes", name: "Sync trades to notes", callback: () => void this.syncToNotes(true) });
    this.addCommand({ id: "create-starter", name: "Create starter trading vault", callback: () => void this.starter() });
    this.scheduleNotes();
    this.addSettingTab(new LedgrSettingTab(this.app, this));
  }
  onunload() {
    this.listeners.clear();
    window.clearTimeout(this.saveTimer);
    window.clearInterval(this.notesTimer);
  }
  // ------------------------------------------------------------------ key
  getKey() {
    const v = this.app.secretStorage?.getSecret(SECRET_ID);
    return v && v.trim() ? v.trim() : null;
  }
  setKey(key) {
    this.app.secretStorage.setSecret(SECRET_ID, key ?? "");
    this.client.clear();
    this.last = null;
    this.emit("state");
  }
  /** Forget the key and everything downloaded from LEDGR (trades cache, profile, calendar). */
  async disconnect() {
    this.app.secretStorage.setSecret(SECRET_ID, "");
    this.client.clear();
    this.last = null;
    this.data.me = null;
    this.data.calendar = null;
    this.cache = { ...EMPTY_CACHE };
    await this.saveData(this.data);
    const p = this.cachePath();
    if (await this.app.vault.adapter.exists(p)) await this.app.vault.adapter.remove(p);
    this.emit("state");
  }
  // ------------------------------------------------------------------ settings and small state
  cfg() {
    return this.data.settings;
  }
  async updateSettings(patch) {
    this.data.settings = { ...this.data.settings, ...patch };
    await this.saveData(this.data);
    if ("notesAuto" in patch) this.scheduleNotes();
    this.emit("settings");
  }
  /** The checklist keeps one entry per day; only the last week is kept. */
  pruneChecklists() {
    const cutoff = isoDate(new Date(Date.now() - 7 * 864e5));
    for (const k of Object.keys(this.data.cc)) if (k.startsWith("cc_ck_") && k !== "cc_ck_items" && k.slice(6) < cutoff) delete this.data.cc[k];
  }
  // ------------------------------------------------------------------ trades
  cachePath() {
    return (0, import_obsidian4.normalizePath)(`${this.manifest.dir}/trades-cache.json`);
  }
  async readCache() {
    if (this.cache) return this.cache;
    try {
      const raw = await this.app.vault.adapter.read(this.cachePath());
      this.cache = { ...EMPTY_CACHE, ...JSON.parse(raw) };
    } catch {
      this.cache = { ...EMPTY_CACHE };
    }
    return this.cache;
  }
  /** Cached trades for an instant render (null before the first sync). */
  cachedTrades() {
    return this.cache && this.cache.lastSync ? { trades: this.cache.trades, at: this.cache.lastSync } : null;
  }
  async loadCache() {
    await this.readCache();
  }
  /** Syncs /me and the trades (new ones only, unless full). Several callers share one run. */
  sync(full = false) {
    if (this.running) return this.running;
    this.running = (async () => {
      const cache = await this.readCache();
      const before = this.last;
      try {
        this.data.me = await this.client.me({ fresh: true });
        const next = await syncTrades((p) => this.client.get(p, { fresh: true }), cache, Date.now(), isoDate(/* @__PURE__ */ new Date()), full);
        this.cache = next;
        await this.app.vault.adapter.write(this.cachePath(), JSON.stringify(next));
        await this.saveData(this.data);
        this.last = { ok: true, at: Date.now() };
        return { ok: true, trades: next.trades, at: next.lastSync };
      } catch (e) {
        const err = e instanceof LedgrApiError ? e : new LedgrApiError("server", "Something went wrong.");
        this.last = { ok: false, at: Date.now(), errorKind: err.kind, message: err.message };
        if (full && err.kind === "rate_limited") new import_obsidian4.Notice("LEDGR: too many requests. Try again in a minute.");
        return { ok: false, kind: err.kind, message: err.message, trades: cache.lastSync ? cache.trades : null, at: cache.lastSync || null };
      } finally {
        this.running = null;
        const was = before && !before.ok ? before.errorKind : null, now = this.last && !this.last.ok ? this.last.errorKind : null;
        if (was !== now) this.emit("state");
      }
    })();
    return this.running;
  }
  /** Automatic note sync every N minutes (setting), while Obsidian is open. */
  scheduleNotes() {
    window.clearInterval(this.notesTimer);
    const m = this.data.settings.notesAuto;
    if (m > 0) {
      this.notesTimer = window.setInterval(() => void this.syncToNotes(false), m * 6e4);
      this.registerInterval(this.notesTimer);
    }
  }
  notesFolder() {
    return (0, import_obsidian4.normalizePath)(this.data.settings.notesFolder.trim() || "LEDGR");
  }
  async noteCtx() {
    try {
      const a = await this.client.get("/accounts", { fresh: true });
      this.data.accounts = Object.fromEntries(a.accounts.map((x) => [x.id, x.name]));
    } catch {
    }
    const tz = this.data.settings.timezone || Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC";
    return { root: this.notesFolder(), tz, accounts: this.data.accounts, currency: this.data.me?.journal?.currency ?? "USD" };
  }
  /** Syncs trades from LEDGR, then writes them as notes. loud: show a notice with the result. */
  syncToNotes(loud) {
    if (this.notesRunning) return this.notesRunning;
    this.notesRunning = (async () => {
      try {
        if (!this.getKey()) {
          if (loud) new import_obsidian4.Notice("LEDGR: connect your API key in Settings \u2192 LEDGR first.");
          return null;
        }
        const s = await this.sync(false);
        if (!s.ok && !s.trades) {
          if (loud) new import_obsidian4.Notice(`LEDGR: ${s.message}`);
          return null;
        }
        const trades = s.ok ? s.trades : s.trades;
        const ctx = await this.noteCtx();
        const today = isoDate(/* @__PURE__ */ new Date());
        const r = await syncNotes(this.app, trades, ctx, today);
        await this.saveData(this.data);
        if (loud) new import_obsidian4.Notice(`LEDGR: ${r.trades} trades \xB7 ${r.created} notes created, ${r.updated} updated${r.deleted ? `, ${r.deleted} marked deleted` : ""}${s.ok ? "" : " (from the offline copy)"}.`);
        if (loud && !this.data.starterAsked) {
          this.data.starterAsked = true;
          await this.saveData(this.data);
          new StarterModal(this.app, () => void this.starter()).open();
        }
        return r;
      } catch (e) {
        if (loud) new import_obsidian4.Notice(`LEDGR: couldn't write the notes (${e.message}).`);
        return null;
      } finally {
        this.notesRunning = null;
      }
    })();
    return this.notesRunning;
  }
  /** Creates the starter vault (asks first when run from the command palette). */
  async starter() {
    const ctx = await this.noteCtx();
    const trades = this.cachedTrades()?.trades ?? [];
    const made = await createStarter(this.app, trades, ctx, isoDate(/* @__PURE__ */ new Date()));
    this.data.starterAsked = true;
    await this.saveData(this.data);
    new import_obsidian4.Notice(made.length ? `LEDGR: created ${made.join(", ")}. Set Settings \u2192 Templates \u2192 Template folder location to "${ctx.root}/Templates" to use the daily template.` : "LEDGR: the starter files are already there.");
  }
  // ------------------------------------------------------------------ calendar
  /** GET /api/v1/calendar. 404 means LEDGR doesn't serve one yet. Last good answer is reused offline. */
  async calendar() {
    const saved = this.data.calendar;
    const fromSaved = (stale) => saved ? { kind: "ok", events: toEvents(saved.answer), updatedAt: saved.answer.updatedAt ?? new Date(saved.at).toISOString(), source: saved.answer.source ?? null, stale } : null;
    try {
      const answer = await this.client.get("/calendar", { fresh: true });
      this.data.calendar = { answer, at: Date.now() };
      await this.saveData(this.data);
      return { kind: "ok", events: toEvents(answer), updatedAt: answer.updatedAt ?? (/* @__PURE__ */ new Date()).toISOString(), source: answer.source ?? null, stale: false };
    } catch (e) {
      const err = e;
      if (err.status === 404) return { kind: "missing" };
      return fromSaved(true) ?? { kind: "error", message: err.message ?? "Couldn't load the calendar." };
    }
  }
  // ------------------------------------------------------------------ intro video (separate file in the plugin folder)
  videoPath() {
    return (0, import_obsidian4.normalizePath)(`${this.manifest.dir}/${VIDEO_FILE}`);
  }
  /** The statue video's URL, downloading it once if it isn't in the plugin folder yet (and a download URL is set). */
  async videoUrl() {
    const p = this.videoPath(), a = this.app.vault.adapter;
    if (!await a.exists(p) && VIDEO_URL) {
      try {
        const res = await (0, import_obsidian4.requestUrl)({ url: VIDEO_URL });
        if (res.status === 200 && res.arrayBuffer.byteLength > 1e3) await a.writeBinary(p, res.arrayBuffer);
      } catch {
      }
    }
    return await a.exists(p) ? a.getResourcePath(p) : null;
  }
  // ------------------------------------------------------------------ helpers for the view
  subscribe(fn) {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }
  emit(what) {
    this.listeners.forEach((fn) => fn(what));
  }
  /**
   * Opens the Command Center clean, like the standalone version: on desktop in its own window with no tabs or
   * sidebars (setting "Open in its own window"); otherwise as a tab with the side panels folded away.
   */
  async openView() {
    const ws = this.app.workspace, existing = ws.getLeavesOfType(VIEW_TYPE)[0];
    if (existing) {
      await ws.revealLeaf(existing);
      return;
    }
    const ownWindow = import_obsidian4.Platform.isDesktopApp && this.data.settings.ownWindow;
    const leaf = ws.getLeaf(ownWindow ? "window" : "tab");
    await leaf.setViewState({ type: VIEW_TYPE, active: true });
    if (!ownWindow) {
      ws.leftSplit.collapse();
      ws.rightSplit.collapse();
    }
    await ws.revealLeaf(leaf);
  }
  openSettings() {
    const setting = this.app.setting;
    setting?.open();
    setting?.openTabById(this.manifest.id);
  }
  /** VAULT button: the vault's home note, if there is one. */
  async openVaultHome() {
    for (const path of ["LEDGR/Home.md", "Home.md", "00 Home.md"]) {
      const f = this.app.vault.getAbstractFileByPath(path);
      if (f instanceof import_obsidian4.TFile) {
        await this.app.workspace.getLeaf(false).openFile(f);
        return;
      }
    }
    new import_obsidian4.Notice("No Home note in this vault yet.");
  }
  /** "Connect with LEDGR": shows a code, opens LEDGR to approve it, and saves the key it gets. Resolves true when connected. */
  connectWithLedgr() {
    return new Promise((resolve) => new ConnectModal(this.app, this, resolve).open());
  }
  ask(title) {
    return new Promise((resolve) => new AskModal(this.app, title, resolve).open());
  }
};
var AskModal = class extends import_obsidian4.Modal {
  constructor(app, title, resolve) {
    super(app);
    this.title = title;
    this.resolve = resolve;
    this.value = "";
    this.done = false;
  }
  onOpen() {
    this.setTitle(this.title);
    const submit = () => {
      this.done = true;
      this.resolve(this.value);
      this.close();
    };
    new import_obsidian4.Setting(this.contentEl).addText((t) => {
      t.onChange((v) => this.value = v);
      t.inputEl.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
          e.preventDefault();
          submit();
        }
      });
      window.setTimeout(() => t.inputEl.focus(), 0);
    }).addButton((b) => b.setButtonText("Add").setCta().onClick(submit));
  }
  onClose() {
    if (!this.done) this.resolve(null);
    this.contentEl.empty();
  }
};
var StarterModal = class extends import_obsidian4.Modal {
  constructor(app, onYes) {
    super(app);
    this.onYes = onYes;
  }
  onOpen() {
    this.setTitle("Set up a trading vault?");
    this.contentEl.createEl("p", { text: "LEDGR can add a starter structure: a Home dashboard that updates on every sync, PARA folders (Projects, Areas, Resources, Archive) and a daily trading-note template. Nothing that already exists is changed." });
    new import_obsidian4.Setting(this.contentEl).addButton((b) => b.setButtonText("Create it").setCta().onClick(() => {
      this.close();
      this.onYes();
    })).addButton((b) => b.setButtonText("No thanks").onClick(() => this.close()));
    this.contentEl.createEl("p", { cls: "setting-item-description", text: 'You can create it later with the command "LEDGR: Create starter trading vault".' });
  }
  onClose() {
    this.contentEl.empty();
  }
};
var ConnectModal = class extends import_obsidian4.Modal {
  constructor(app, plugin, resolve) {
    super(app);
    this.plugin = plugin;
    this.resolve = resolve;
    this.cancelled = false;
    this.ok = false;
  }
  async onOpen() {
    this.setTitle("Connect with LEDGR");
    const el = this.contentEl;
    const status = el.createEl("p", { text: "Getting a code\u2026" });
    try {
      const code = await this.plugin.connectSteps.start();
      if (this.cancelled) return;
      status.setText("Approve this code in LEDGR. It's opening in your browser now:");
      const box = el.createDiv({ cls: "ledgr-connect-code", text: code.user_code });
      box.setAttr("aria-label", `Code ${code.user_code.split("").join(" ")}`);
      const waiting = el.createEl("p", { cls: "setting-item-description", text: "Waiting for you to approve\u2026 (the code works for 15 minutes)" });
      new import_obsidian4.Setting(el).addButton((b) => b.setButtonText("Open LEDGR again").onClick(() => window.open(code.verification_uri_complete))).addButton((b) => b.setButtonText("Cancel").onClick(() => this.close()));
      window.open(code.verification_uri_complete);
      const key = await this.plugin.connectSteps.wait(code, () => this.cancelled);
      if (!key) return;
      waiting.setText("Approved. Connecting\u2026");
      await this.plugin.connectSteps.finish(key);
      this.ok = true;
      new import_obsidian4.Notice("LEDGR: connected.");
      this.close();
    } catch (e) {
      if (this.cancelled) return;
      status.setText(e.message || "Couldn't connect.");
      status.addClass("mod-warning");
    }
  }
  onClose() {
    this.cancelled = true;
    this.contentEl.empty();
    this.resolve(this.ok);
  }
};
